"use client";

import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { BackgroundVideo } from "@/components/media/BackgroundVideo";
import { Aurora } from "@/components/media/Aurora";
import { testimonials } from "@/lib/content";

// duplicate for a seamless marquee loop
const row = [...testimonials, ...testimonials];

export function Testimonials() {
  return (
    <section className="relative overflow-hidden py-20 sm:py-28">
      <BackgroundVideo
        video="testimonials"
        overlayClassName="bg-void/82"
        fallback={<Aurora tone="purple" />}
      />
      <div className="container relative">
        <SectionHeading
          eyebrow="Loved by users"
          title="People are eating smarter with CareMate"
          description="Real stories from a growing community of health-conscious users."
        />
      </div>

      <div className="mask-fade-x relative mt-14 flex flex-col gap-5">
        <Marquee items={row} direction="left" />
        <Marquee items={[...row].reverse()} direction="right" />
      </div>
    </section>
  );
}

function Marquee({
  items,
  direction,
}: {
  items: typeof row;
  direction: "left" | "right";
}) {
  return (
    <div className="group flex overflow-hidden">
      <div
        className="flex shrink-0 gap-5 pr-5"
        style={{
          animation: `marquee 48s linear infinite`,
          animationDirection: direction === "right" ? "reverse" : "normal",
        }}
      >
        {items.map((t, i) => (
          <Card key={`${t.name}-${i}`} t={t} />
        ))}
      </div>
      <div
        aria-hidden
        className="flex shrink-0 gap-5 pr-5"
        style={{
          animation: `marquee 48s linear infinite`,
          animationDirection: direction === "right" ? "reverse" : "normal",
        }}
      >
        {items.map((t, i) => (
          <Card key={`dup-${t.name}-${i}`} t={t} />
        ))}
      </div>
    </div>
  );
}

function Card({ t }: { t: (typeof testimonials)[number] }) {
  return (
    <motion.figure
      whileHover={{ y: -4 }}
      className="card-dark flex w-[320px] shrink-0 flex-col p-6"
    >
      <div className="flex gap-0.5">
        {Array.from({ length: t.rating }).map((_, i) => (
          <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
        ))}
      </div>
      <blockquote className="mt-4 flex-1 text-[15px] leading-relaxed text-slate-300">
        “{t.quote}”
      </blockquote>
      <figcaption className="mt-5 flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-primary to-neon-cyan text-sm font-bold text-void">
          {t.initials}
        </span>
        <span className="flex flex-col leading-tight">
          <span className="text-sm font-bold text-white">{t.name}</span>
          <span className="text-xs text-slate-500">{t.role}</span>
        </span>
      </figcaption>
    </motion.figure>
  );
}
