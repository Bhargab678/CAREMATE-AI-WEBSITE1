import { Hero } from "@/components/sections/Hero";
import { Screenshots } from "@/components/sections/Screenshots";
import { ScannerCinematic } from "@/components/sections/ScannerCinematic";
import { StoryScroll } from "@/components/sections/StoryScroll";
import { Features } from "@/components/sections/Features";
import { AiChat } from "@/components/sections/AiChat";
import { StatsBand } from "@/components/sections/StatsBand";
import { WhyChoose } from "@/components/sections/WhyChoose";
import { Pricing } from "@/components/sections/Pricing";
import { Testimonials } from "@/components/sections/Testimonials";
import { BlogPreview } from "@/components/sections/BlogPreview";
import { Faq } from "@/components/sections/Faq";
import { Cta } from "@/components/sections/Cta";
import { FaqJsonLd } from "@/components/seo/JsonLd";
import { getAllPosts } from "@/lib/blog";
import { faqs } from "@/lib/content";

export default function HomePage() {
  const posts = getAllPosts();

  return (
    <>
      <FaqJsonLd items={faqs} />
      {/* S1 */} <Hero />
      {/* S2 */} <Screenshots />
      {/* S3 */} <ScannerCinematic />
      {/* S4 */} <StoryScroll />
      {/* S5 */} <Features />
      {/* S6 */} <AiChat />
      {/* S7 */} <StatsBand />
      <WhyChoose />
      <Pricing />
      {/* S8 */} <Testimonials />
      <BlogPreview posts={posts} />
      <Faq />
      {/* S9 */} <Cta />
    </>
  );
}
