"use client";

import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import gsap from "gsap";
import { seeded } from "../utils";
import { PALETTE } from "../config";

/* A thin glowing plane that sweeps vertically — the "AI scan". Driven by GSAP. */
function ScanBeam({ reduced }: { reduced: boolean }) {
  const ref = useRef<THREE.Mesh>(null);

  useEffect(() => {
    if (reduced || !ref.current) return;
    ref.current.position.y = -5;
    const tl = gsap.timeline({ repeat: -1, repeatDelay: 2.5 });
    tl.to(ref.current.position, { y: 5, duration: 4, ease: "sine.inOut" });
    const mat = ref.current.material as THREE.Material;
    tl.fromTo(mat, { opacity: 0 }, { opacity: 0.14, duration: 1 }, 0);
    tl.to(mat, { opacity: 0, duration: 1 }, 3);
    return () => {
      tl.kill();
    };
  }, [reduced]);

  if (reduced) return null;
  return (
    <mesh ref={ref} position={[0, 0, -3]} rotation={[Math.PI / 2, 0, 0]}>
      <planeGeometry args={[26, 6]} />
      <meshBasicMaterial
        color={PALETTE.sky}
        transparent
        opacity={0}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

/* A few slowly rotating holographic rings. */
function HoloRings({ reduced }: { reduced: boolean }) {
  const g = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (g.current && !reduced) {
      g.current.rotation.z = state.clock.elapsedTime * 0.05;
      g.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.1) * 0.15;
    }
  });
  const rings = [
    { r: 3.4, color: PALETTE.sky, op: 0.18 },
    { r: 4.6, color: PALETTE.primary, op: 0.12 },
    { r: 6.0, color: PALETTE.blue, op: 0.08 },
  ];
  return (
    <group ref={g} position={[0, 0, -5]}>
      {rings.map((ring, i) => (
        <mesh key={i} rotation={[Math.PI / 2.4, 0, i * 0.4]}>
          <torusGeometry args={[ring.r, 0.012, 8, 120]} />
          <meshBasicMaterial
            color={ring.color}
            transparent
            opacity={ring.op}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
          />
        </mesh>
      ))}
    </group>
  );
}

/* A faint neural graph: nodes connected by lines, with soft glowing dots. */
function NeuralNet({ reduced }: { reduced: boolean }) {
  const group = useRef<THREE.Group>(null);

  const { linePositions, nodePositions } = useMemo(() => {
    const rand = seeded(88);
    const N = 14;
    const nodes: THREE.Vector3[] = [];
    for (let i = 0; i < N; i++) {
      nodes.push(
        new THREE.Vector3((rand() * 2 - 1) * 8, (rand() * 2 - 1) * 4.5, -6 - rand() * 2)
      );
    }
    const segs: number[] = [];
    for (let i = 0; i < N; i++) {
      const dists = nodes
        .map((n, j) => ({ j, d: nodes[i].distanceTo(n) }))
        .filter((o) => o.j !== i)
        .sort((a, b) => a.d - b.d)
        .slice(0, 2);
      for (const { j } of dists) {
        segs.push(nodes[i].x, nodes[i].y, nodes[i].z, nodes[j].x, nodes[j].y, nodes[j].z);
      }
    }
    return {
      linePositions: new Float32Array(segs),
      nodePositions: nodes,
    };
  }, []);

  useFrame((state) => {
    if (group.current && !reduced) {
      group.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.06) * 0.12;
    }
  });

  return (
    <group ref={group}>
      <lineSegments>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[linePositions, 3]}
            count={linePositions.length / 3}
          />
        </bufferGeometry>
        <lineBasicMaterial
          color={PALETTE.sky}
          transparent
          opacity={0.14}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </lineSegments>
      {nodePositions.map((p, i) => (
        <mesh key={i} position={p}>
          <sphereGeometry args={[0.05, 12, 12]} />
          <meshBasicMaterial color={PALETTE.primary} />
        </mesh>
      ))}
    </group>
  );
}

export function AiEffects({ reduced }: { reduced: boolean }) {
  return (
    <group>
      <NeuralNet reduced={reduced} />
      <HoloRings reduced={reduced} />
      <ScanBeam reduced={reduced} />
    </group>
  );
}
