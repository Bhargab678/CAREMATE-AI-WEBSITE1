import fs from "fs";
import path from "path";
import matter from "gray-matter";
import { readingTime } from "@/lib/utils";

const BLOG_DIR = path.join(process.cwd(), "src", "content", "blog");

export interface BlogPostMeta {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  author: string;
  authorRole: string;
  cover: string;
  featured: boolean;
  readingTime: number;
  tags: string[];
}

export interface BlogPost extends BlogPostMeta {
  content: string;
}

function ensureDir(): boolean {
  return fs.existsSync(BLOG_DIR);
}

export function getAllPosts(): BlogPostMeta[] {
  if (!ensureDir()) return [];
  const files = fs.readdirSync(BLOG_DIR).filter((f) => /\.mdx?$/.test(f));

  const posts = files.map((file) => {
    const slug = file.replace(/\.mdx?$/, "");
    const raw = fs.readFileSync(path.join(BLOG_DIR, file), "utf-8");
    const { data, content } = matter(raw);
    return {
      slug,
      title: data.title ?? slug,
      excerpt: data.excerpt ?? "",
      date: data.date ?? new Date().toISOString(),
      category: data.category ?? "Health",
      author: data.author ?? "CareMate Team",
      authorRole: data.authorRole ?? "Nutrition Editorial",
      cover: data.cover ?? "",
      featured: Boolean(data.featured),
      tags: data.tags ?? [],
      readingTime: readingTime(content),
    } satisfies BlogPostMeta;
  });

  return posts.sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );
}

export function getPostBySlug(slug: string): BlogPost | null {
  if (!ensureDir()) return null;
  const mdx = path.join(BLOG_DIR, `${slug}.mdx`);
  const md = path.join(BLOG_DIR, `${slug}.md`);
  const filePath = fs.existsSync(mdx) ? mdx : fs.existsSync(md) ? md : null;
  if (!filePath) return null;

  const raw = fs.readFileSync(filePath, "utf-8");
  const { data, content } = matter(raw);

  return {
    slug,
    title: data.title ?? slug,
    excerpt: data.excerpt ?? "",
    date: data.date ?? new Date().toISOString(),
    category: data.category ?? "Health",
    author: data.author ?? "CareMate Team",
    authorRole: data.authorRole ?? "Nutrition Editorial",
    cover: data.cover ?? "",
    featured: Boolean(data.featured),
    tags: data.tags ?? [],
    readingTime: readingTime(content),
    content,
  };
}

export function getCategories(): string[] {
  const posts = getAllPosts();
  return Array.from(new Set(posts.map((p) => p.category))).sort();
}

export function getFeaturedPost(): BlogPostMeta | null {
  const posts = getAllPosts();
  return posts.find((p) => p.featured) ?? posts[0] ?? null;
}
