import Link from "next/link";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { siteConfig } from "@/lib/site";

interface LogoProps {
  className?: string;
  showWordmark?: boolean;
  href?: string | null;
  /** Use light wordmark text over dark backgrounds (e.g. the hero). */
  light?: boolean;
}

/**
 * Brand mark for CareMate AI — the official running-figure app icon.
 * Source of truth is `public/logo.png` (2000×2000). Served through next/image
 * so it is auto-optimized to AVIF/WebP at the exact rendered size.
 */
export function LogoMark({ className }: { className?: string }) {
  return (
    <Image
      src="/logo.png"
      alt=""
      aria-hidden="true"
      width={96}
      height={96}
      priority
      className={cn(
        "rounded-[24%] object-contain ring-1 ring-white/10 drop-shadow-[0_8px_22px_rgba(34,211,238,0.28)]",
        className
      )}
    />
  );
}

export function Logo({
  className,
  showWordmark = true,
  href = "/",
  light = true,
}: LogoProps) {
  const inner = (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark className="h-9 w-9" />
      {showWordmark && (
        <span className="flex flex-col leading-none">
          <span
            className={cn(
              "font-display text-lg font-extrabold tracking-tight transition-colors",
              light ? "text-white" : "text-ink"
            )}
          >
            {siteConfig.name}
          </span>
        </span>
      )}
    </span>
  );

  if (href === null) return inner;

  return (
    <Link href={href} className="btn-focus rounded-xl" aria-label={siteConfig.name}>
      {inner}
    </Link>
  );
}
