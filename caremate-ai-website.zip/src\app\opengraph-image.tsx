import { ImageResponse } from "next/og";
import { siteConfig } from "@/lib/site";
import { logoTileDataUri } from "@/lib/brand";

export const alt = `${siteConfig.name} — ${siteConfig.tagline}`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OgImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 80,
          background: "#0B1220",
          backgroundImage:
            "radial-gradient(circle at 15% 15%, rgba(16,185,129,0.35), transparent 45%), radial-gradient(circle at 85% 80%, rgba(59,130,246,0.35), transparent 45%)",
          color: "white",
          fontFamily: "sans-serif",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={logoTileDataUri}
            width={72}
            height={72}
            alt=""
            style={{ borderRadius: 18 }}
          />
          <span style={{ fontSize: 34, fontWeight: 700 }}>{siteConfig.name}</span>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <span
            style={{
              fontSize: 30,
              color: "#34d399",
              fontWeight: 600,
              letterSpacing: 2,
              textTransform: "uppercase",
            }}
          >
            AI food scanner · Verified nutrition
          </span>
          <span style={{ fontSize: 74, fontWeight: 800, lineHeight: 1.05, maxWidth: 940 }}>
            Your personal AI health assistant
          </span>
        </div>

        <span style={{ fontSize: 26, color: "rgba(255,255,255,0.6)" }}>
          Scan food · Track nutrition · Chat with AI
        </span>
      </div>
    ),
    { ...size }
  );
}
