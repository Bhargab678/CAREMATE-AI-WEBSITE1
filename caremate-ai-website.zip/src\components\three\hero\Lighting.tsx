"use client";

import { Environment } from "@react-three/drei";
import { PALETTE } from "./config";

export function Lighting({ shadows }: { shadows: boolean }) {
  return (
    <>
      <ambientLight intensity={0.5} color="#cfe0ff" />

      {/* Key light — soft shadows */}
      <directionalLight
        position={[5, 8, 5]}
        intensity={2.1}
        color="#ffffff"
        castShadow={shadows}
        shadow-mapSize-width={shadows ? 1024 : 256}
        shadow-mapSize-height={shadows ? 1024 : 256}
        shadow-bias={-0.0004}
        shadow-camera-near={1}
        shadow-camera-far={30}
        shadow-camera-left={-12}
        shadow-camera-right={12}
        shadow-camera-top={12}
        shadow-camera-bottom={-12}
      />

      {/* Cool rim + brand fill for a premium AI mood */}
      <directionalLight position={[-6, -2, -3]} intensity={0.7} color={PALETTE.sky} />
      <pointLight position={[-4, 2, 4]} intensity={40} distance={18} color={PALETTE.primary} />
      <pointLight position={[5, -3, 3]} intensity={30} distance={16} color={PALETTE.blue} />

      {/* Image-based lighting for glossy reflections */}
      <Environment preset="night" />
    </>
  );
}
