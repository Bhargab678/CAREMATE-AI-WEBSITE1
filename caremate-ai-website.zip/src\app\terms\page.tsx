import type { Metadata } from "next";
import { LegalPage } from "@/components/layout/LegalPage";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description:
    "The terms and conditions governing your use of the CareMate AI app and website.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <LegalPage
      title="Terms & Conditions"
      updated="July 21, 2026"
      intro={`Welcome to ${siteConfig.name}. By accessing or using our app and website, you agree to be bound by these Terms & Conditions. Please read them carefully.`}
      sections={[
        {
          heading: "Acceptance of terms",
          body: [
            "By downloading, accessing, or using CareMate AI, you agree to these Terms. If you do not agree, please do not use the service.",
          ],
        },
        {
          heading: "Use of the service",
          body: [
            "You must be at least 13 years old to use CareMate AI.",
            "You agree to use the service only for lawful purposes and not to misuse, reverse-engineer, or disrupt it.",
          ],
        },
        {
          heading: "Health disclaimer",
          body: [
            "CareMate AI provides nutritional information and insights for general wellness purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment.",
            "Always consult a qualified healthcare provider regarding any medical condition or before making significant changes to your diet.",
          ],
        },
        {
          heading: "Accounts",
          body: [
            "You are responsible for maintaining the confidentiality of your account credentials and for all activity under your account.",
          ],
        },
        {
          heading: "Subscriptions and payments",
          body: [
            "CareMate AI offers free and paid plans. Paid subscriptions are billed through the applicable app store and renew automatically unless cancelled.",
            "You can manage or cancel subscriptions through your app store account settings.",
          ],
        },
        {
          heading: "Intellectual property",
          body: [
            "All content, trademarks, and software associated with CareMate AI are owned by us or our licensors and are protected by applicable laws.",
          ],
        },
        {
          heading: "Limitation of liability",
          body: [
            "To the maximum extent permitted by law, CareMate AI shall not be liable for any indirect, incidental, or consequential damages arising from your use of the service.",
          ],
        },
        {
          heading: "Changes to these terms",
          body: [
            "We may update these Terms from time to time. Continued use of the service after changes constitutes acceptance of the revised Terms.",
          ],
        },
        {
          heading: "Contact",
          body: [`For questions about these Terms, contact us at ${siteConfig.email}.`],
        },
      ]}
    />
  );
}
