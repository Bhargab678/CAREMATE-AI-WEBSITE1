"use client";

import { motion } from "framer-motion";
import { CinematicSection } from "@/components/media/CinematicSection";
import { Counter } from "@/components/motion/Counter";

const METRICS = [
  { value: "2.4M+", label: "Meals analyzed" },
  { value: "480M+", label: "Calories calculated" },
  { value: "310K+", label: "Health reports" },
  { value: "120K+", label: "Daily users" },
];

export function StatsBand() {
  return (
    <CinematicSection video="stats" tone="cyan" overlay="bg-void/80" grid={false}>
      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
        {METRICS.map((m, i) => (
          <motion.div
            key={m.label}
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ delay: i * 0.08, duration: 0.55 }}
            className="text-center"
          >
            <Counter
              value={m.value}
              className="block bg-gradient-to-b from-white to-slate-400 bg-clip-text text-4xl font-extrabold text-transparent sm:text-5xl"
            />
            <p className="mt-2 text-xs font-medium uppercase tracking-[0.2em] text-slate-500">
              {m.label}
            </p>
          </motion.div>
        ))}
      </div>
    </CinematicSection>
  );
}
