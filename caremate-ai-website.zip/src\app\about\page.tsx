import type { Metadata } from "next";
import { Target, Eye, Heart, Sparkles, ShieldCheck, Leaf } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/motion/Reveal";
import { Counter } from "@/components/motion/Counter";
import { Cta } from "@/components/sections/Cta";
import { stats } from "@/lib/content";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "About",
  description:
    "The story and mission behind CareMate AI — making accurate, verified nutrition tracking effortless for everyone.",
  alternates: { canonical: "/about" },
};

const values = [
  {
    icon: ShieldCheck,
    title: "Accuracy first",
    description:
      "We never let an algorithm guess your nutrition. Every number is grounded in verified data you can trust.",
  },
  {
    icon: Heart,
    title: "Health, not guilt",
    description:
      "We design for a positive relationship with food — gentle guidance instead of shame-driven counting.",
  },
  {
    icon: Sparkles,
    title: "Effortless by default",
    description:
      "Great health tools disappear into your life. If it's not simple, people won't stick with it.",
  },
  {
    icon: Leaf,
    title: "Privacy respected",
    description:
      "Your body is personal. We process on-device where possible and never sell your data.",
  },
];

export default function AboutPage() {
  return (
    <>
      <PageHeader
        eyebrow="Our story"
        title="Making healthy eating effortless for everyone"
        description={`${siteConfig.name} started with a simple frustration: tracking what you eat shouldn't take longer than eating it — and the numbers should actually be right.`}
      />

      <section className="pb-8">
        <div className="container">
          <div className="grid gap-4 card-dark p-6 sm:grid-cols-4 sm:p-8">
            {stats.map((s) => (
              <Reveal key={s.label} className="text-center">
                <Counter
                  value={s.value}
                  className="block text-3xl font-extrabold text-white"
                />
                <p className="mt-1 text-xs font-medium uppercase tracking-wide text-slate-500">
                  {s.label}
                </p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-20">
        <div className="container grid gap-10 lg:grid-cols-2">
          <Reveal>
            <div className="card-dark h-full p-8">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-primary/25 to-neon-cyan/10 text-neon-cyan ring-1 ring-white/10">
                <Target className="h-6 w-6" />
              </div>
              <h2 className="mt-5 text-2xl font-bold text-white">Our mission</h2>
              <p className="mt-3 leading-relaxed text-slate-400">
                To help a billion people understand what they eat — instantly and
                accurately — so they can make small, sustainable choices that add up
                to a healthier life. We combine computer vision with a rigorously
                verified nutrition database so guidance is always trustworthy.
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.08}>
            <div className="card-dark h-full p-8">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-neon-purple/25 to-neon-blue/10 text-neon-purple ring-1 ring-white/10">
                <Eye className="h-6 w-6" />
              </div>
              <h2 className="mt-5 text-2xl font-bold text-white">Our vision</h2>
              <p className="mt-3 leading-relaxed text-slate-400">
                A world where nutrition tracking is so simple and calm that it fades
                into the background of daily life — quietly nudging everyone toward
                better health, without stress, guilt or friction.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="relative py-16 sm:py-24">
        <div className="container">
          <SectionHeading
            eyebrow="What we value"
            title="Principles that guide every decision"
          />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={i * 0.06}>
                <div className="card-dark card-hover h-full p-6">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-primary/25 to-neon-cyan/10 text-neon-cyan ring-1 ring-white/10">
                    <v.icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-4 text-base font-bold text-white">{v.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-400">
                    {v.description}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <Cta />
    </>
  );
}
