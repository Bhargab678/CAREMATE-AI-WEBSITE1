import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface PhoneFrameProps {
  children: ReactNode;
  className?: string;
  glow?: boolean;
}

/**
 * A realistic phone chassis. The screen area is a fixed 9:19.5 aspect ratio
 * dark canvas that the app-screen components render into.
 */
export function PhoneFrame({ children, className, glow = true }: PhoneFrameProps) {
  return (
    <div className={cn("relative", className)}>
      {glow && (
        <div
          aria-hidden
          className="absolute -inset-8 -z-10 rounded-[3rem] bg-gradient-to-tr from-primary/25 via-accent/10 to-secondary/25 blur-3xl"
        />
      )}
      <div className="relative mx-auto w-full max-w-[300px] rounded-[2.75rem] border border-slate-800 bg-slate-950 p-2.5 shadow-2xl ring-1 ring-black/5">
        {/* side buttons */}
        <span className="absolute -left-[3px] top-24 h-9 w-[3px] rounded-l bg-slate-800" />
        <span className="absolute -left-[3px] top-36 h-14 w-[3px] rounded-l bg-slate-800" />
        <span className="absolute -right-[3px] top-32 h-16 w-[3px] rounded-r bg-slate-800" />

        <div className="relative overflow-hidden rounded-[2.25rem] bg-black">
          {/* notch */}
          <div className="pointer-events-none absolute left-1/2 top-2 z-20 h-6 w-24 -translate-x-1/2 rounded-full bg-black" />
          <div className="relative aspect-[9/19.5] w-full overflow-hidden">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
