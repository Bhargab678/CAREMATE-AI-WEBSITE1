import type { Metadata } from "next";
import { Mail, MessageCircle, MapPin, Clock } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { ContactForm } from "@/components/ContactForm";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Get in touch with the CareMate AI team — questions, feedback, partnerships and press.",
  alternates: { canonical: "/contact" },
};

const details = [
  {
    icon: Mail,
    label: "Email us",
    value: siteConfig.email,
    href: `mailto:${siteConfig.email}`,
  },
  {
    icon: MessageCircle,
    label: "Support",
    value: "In-app help center",
    href: siteConfig.links.playStore,
  },
  { icon: MapPin, label: "Location", value: "Remote-first · Worldwide" },
  { icon: Clock, label: "Response time", value: "Within 1–2 business days" },
];

export default function ContactPage() {
  return (
    <>
      <PageHeader
        eyebrow="Contact"
        title="We'd love to hear from you"
        description="Questions, feedback or partnership ideas? Send us a message and we'll get back to you soon."
      />

      <section className="pb-24">
        <div className="container grid gap-10 lg:grid-cols-[1fr_1.4fr]">
          <div className="space-y-4">
            {details.map((d) => {
              const inner = (
                <div className="card-dark card-hover flex items-start gap-4 p-5">
                  <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-primary/25 to-neon-cyan/10 text-neon-cyan ring-1 ring-white/10">
                    <d.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">{d.label}</p>
                    <p className="mt-0.5 text-sm text-slate-400">{d.value}</p>
                  </div>
                </div>
              );
              return d.href ? (
                <a
                  key={d.label}
                  href={d.href}
                  className="btn-focus block rounded-3xl"
                >
                  {inner}
                </a>
              ) : (
                <div key={d.label}>{inner}</div>
              );
            })}
          </div>

          <ContactForm />
        </div>
      </section>
    </>
  );
}
