"use client";

/**
 * Global error boundary — the last line of defense. Catches errors thrown in the
 * root layout itself (which the segment-level error.tsx cannot). It must render
 * its own <html>/<body> because it replaces the whole document.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#050505",
          color: "#fff",
          fontFamily: "system-ui, sans-serif",
          textAlign: "center",
          padding: "2rem",
        }}
      >
        <div style={{ maxWidth: 460 }}>
          <h1 style={{ fontSize: "1.75rem", fontWeight: 800, margin: 0 }}>
            CareMate AI
          </h1>
          <p style={{ marginTop: "1rem", color: "rgba(255,255,255,0.65)" }}>
            The application ran into an unexpected error. Please reload the page.
          </p>
          <button
            onClick={reset}
            style={{
              marginTop: "1.5rem",
              height: 48,
              padding: "0 1.75rem",
              borderRadius: 999,
              border: "none",
              background: "#10b981",
              color: "#fff",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Reload
          </button>
        </div>
      </body>
    </html>
  );
}
