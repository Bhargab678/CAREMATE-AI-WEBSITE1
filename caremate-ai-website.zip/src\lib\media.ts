/**
 * Central media configuration for cinematic background videos.
 *
 * ── HOW TO ENABLE VIDEO BACKGROUNDS ──────────────────────────────────────────
 * 1. Add your optimized files to `public/videos/` (see public/videos/README.md
 *    for exact filenames, themes and ffmpeg compression commands).
 * 2. Set `videoBackgrounds: true` below.
 * Every section upgrades automatically — lazy-loading, off-screen pausing,
 * poster frames and prefers-reduced-motion fallbacks are already handled.
 *
 * While `videoBackgrounds` is false (the default), each section renders its
 * animated aurora/particle fallback, so the site always looks finished and
 * there are no broken <video> requests.
 */
export const mediaConfig = {
  videoBackgrounds: false,

  videos: {
    /** S1 — fullscreen hero: neural net / DNA / medical holograms */
    hero: {
      webm: "/videos/hero.webm",
      mp4: "/videos/hero.mp4",
      poster: "/videos/hero-poster.jpg",
    },
    /** S2 — 3D phone rotating, app UI playing inside */
    phone: {
      webm: "/videos/phone.webm",
      mp4: "/videos/phone.mp4",
      poster: "/videos/phone-poster.jpg",
    },
    /** S3 — food scanner cinematic: meal scanned, particles, score */
    scanner: {
      webm: "/videos/scanner.webm",
      mp4: "/videos/scanner.mp4",
      poster: "/videos/scanner-poster.jpg",
    },
    /** S4 — horizontal story backdrop */
    story: {
      webm: "/videos/story.webm",
      mp4: "/videos/story.mp4",
      poster: "/videos/story-poster.jpg",
    },
    /** S5 — feature showcase ambience */
    features: {
      webm: "/videos/features.webm",
      mp4: "/videos/features.mp4",
      poster: "/videos/features-poster.jpg",
    },
    /** S6 — AI chat hologram */
    chat: {
      webm: "/videos/chat.webm",
      mp4: "/videos/chat.mp4",
      poster: "/videos/chat-poster.jpg",
    },
    /** S7 — stats: moving digital particles */
    stats: {
      webm: "/videos/stats.webm",
      mp4: "/videos/stats.mp4",
      poster: "/videos/stats-poster.jpg",
    },
    /** S8 — testimonials: slow-motion gradient */
    testimonials: {
      webm: "/videos/testimonials.webm",
      mp4: "/videos/testimonials.mp4",
      poster: "/videos/testimonials-poster.jpg",
    },
    /** Pricing ambience */
    pricing: {
      webm: "/videos/pricing.webm",
      mp4: "/videos/pricing.mp4",
      poster: "/videos/pricing-poster.jpg",
    },
    /** S9 — epic download CTA */
    cta: {
      webm: "/videos/cta.webm",
      mp4: "/videos/cta.mp4",
      poster: "/videos/cta-poster.jpg",
    },
    /** Footer — animated wave */
    footer: {
      webm: "/videos/footer.webm",
      mp4: "/videos/footer.mp4",
      poster: "/videos/footer-poster.jpg",
    },
  },
} as const;

export type VideoKey = keyof typeof mediaConfig.videos;
