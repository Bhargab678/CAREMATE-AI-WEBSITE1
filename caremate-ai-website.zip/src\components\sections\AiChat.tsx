"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Sparkles, Mic } from "lucide-react";
import { CinematicSection } from "@/components/media/CinematicSection";
import { Reveal } from "@/components/motion/Reveal";

const THREAD = [
  { from: "user", text: "I had two chapatis, dal and a boiled egg. How did I do?" },
  { from: "ai", text: "That's ~430 kcal with 21g protein — a solid, balanced dinner. 👌" },
  { from: "user", text: "Am I hitting my protein goal today?" },
  { from: "ai", text: "You're at 96g of 130g. A cup of Greek yogurt tonight would close most of the gap." },
];

function Waveform() {
  const reduce = useReducedMotion();
  const bars = Array.from({ length: 22 });
  return (
    <div className="flex h-8 items-center gap-[3px]">
      {bars.map((_, i) => (
        <motion.span
          key={i}
          className="w-[3px] rounded-full bg-gradient-to-t from-primary to-neon-cyan"
          initial={{ height: 6 }}
          animate={reduce ? { height: 12 } : { height: [6, 10 + ((i * 7) % 22), 6] }}
          transition={{
            duration: 1.1 + (i % 5) * 0.12,
            repeat: reduce ? 0 : Infinity,
            ease: "easeInOut",
            delay: i * 0.05,
          }}
        />
      ))}
    </div>
  );
}

function TypingDots() {
  const reduce = useReducedMotion();
  return (
    <span className="inline-flex items-center gap-1">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="h-1.5 w-1.5 rounded-full bg-slate-400"
          animate={reduce ? undefined : { opacity: [0.3, 1, 0.3], y: [0, -2, 0] }}
          transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.18 }}
        />
      ))}
    </span>
  );
}

export function AiChat() {
  return (
    <CinematicSection video="chat" tone="purple" overlay="bg-void/78">
      <div className="grid items-center gap-14 lg:grid-cols-2">
        <div>
          <Reveal>
            <span className="eyebrow">
              <Sparkles className="h-3.5 w-3.5 text-neon-cyan" />
              CareMate Assistant
            </span>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="h-section mt-5">
              Ask anything about <span className="text-gradient">your nutrition</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="p-section mt-4 max-w-xl">
              A health assistant that actually knows your day. It reads your logged
              meals, understands your goals, and answers in plain language — by text
              or by voice.
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-8 flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-4 backdrop-blur">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary to-neon-cyan text-void">
                <Mic className="h-4 w-4" />
              </span>
              <Waveform />
              <span className="ml-auto text-xs font-medium uppercase tracking-widest text-slate-500">
                Listening
              </span>
            </div>
          </Reveal>
        </div>

        {/* chat panel */}
        <Reveal delay={0.1}>
          <div className="card-dark relative p-5 sm:p-6">
            <div className="absolute -inset-px -z-10 rounded-3xl bg-gradient-to-br from-neon-cyan/25 via-transparent to-neon-purple/25 blur-lg" />
            <div className="flex items-center gap-2 border-b border-white/10 pb-4">
              <span className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-primary to-neon-cyan text-void">
                <Sparkles className="h-4 w-4" />
              </span>
              <span className="text-sm font-semibold text-white">CareMate AI</span>
              <span className="ml-auto flex items-center gap-1.5 text-[11px] text-emerald-400">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Online
              </span>
            </div>

            <div className="mt-4 space-y-3">
              {THREAD.map((m, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 14 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{ delay: i * 0.25, duration: 0.5 }}
                  className={m.from === "user" ? "flex justify-end" : "flex justify-start"}
                >
                  <p
                    className={
                      m.from === "user"
                        ? "max-w-[85%] rounded-2xl rounded-br-md bg-gradient-to-br from-primary to-neon-cyan px-4 py-2.5 text-sm font-medium text-void"
                        : "max-w-[85%] rounded-2xl rounded-bl-md border border-white/10 bg-white/[0.06] px-4 py-2.5 text-sm text-slate-200"
                    }
                  >
                    {m.text}
                  </p>
                </motion.div>
              ))}

              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 1.1 }}
                className="flex justify-start"
              >
                <span className="rounded-2xl rounded-bl-md border border-white/10 bg-white/[0.06] px-4 py-3">
                  <TypingDots />
                </span>
              </motion.div>
            </div>
          </div>
        </Reveal>
      </div>
    </CinematicSection>
  );
}
