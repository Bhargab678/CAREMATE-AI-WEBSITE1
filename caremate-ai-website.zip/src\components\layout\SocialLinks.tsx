"use client";

import { motion } from "framer-motion";
import { Twitter, Instagram, Linkedin, Github, Mail } from "lucide-react";
import { siteConfig } from "@/lib/site";

const items = [
  { icon: Mail, href: `mailto:${siteConfig.email}`, label: "Email", external: false },
  { icon: Twitter, href: siteConfig.links.twitter, label: "Twitter", external: true },
  { icon: Instagram, href: siteConfig.links.instagram, label: "Instagram", external: true },
  { icon: Linkedin, href: siteConfig.links.linkedin, label: "LinkedIn", external: true },
  { icon: Github, href: siteConfig.links.github, label: "GitHub", external: true },
];

export function SocialLinks() {
  return (
    <div className="flex items-center gap-3">
      {items.map((s, i) => (
        <motion.a
          key={s.label}
          href={s.href}
          {...(s.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
          aria-label={s.label}
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.06, duration: 0.4 }}
          whileHover={{ y: -4, scale: 1.08 }}
          whileTap={{ scale: 0.94 }}
          className="btn-focus grid h-10 w-10 place-items-center rounded-full border border-white/10 bg-white/5 text-slate-400 backdrop-blur transition-colors hover:border-neon-cyan/60 hover:text-neon-cyan"
        >
          <s.icon className="h-4 w-4" />
        </motion.a>
      ))}
    </div>
  );
}
