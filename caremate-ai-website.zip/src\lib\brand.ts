import fs from "fs";
import path from "path";

// Server-only brand asset. Imported ONLY by route modules that generate images
// (app/icon.tsx, app/opengraph-image.tsx). Reads from disk at build time, so
// never import this from a client component.

/**
 * The official CareMate AI logo (public/logo.png) as a base64 data URI.
 * `next/og` cannot fetch relative URLs during static generation, so the bytes
 * are inlined here instead.
 */
export const logoTileDataUri = (() => {
  const file = path.join(process.cwd(), "public", "logo.png");
  const b64 = fs.readFileSync(file).toString("base64");
  return `data:image/png;base64,${b64}`;
})();
