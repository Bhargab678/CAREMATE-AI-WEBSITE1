import {
  ScanLine,
  Flame,
  Salad,
  LayoutDashboard,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  Zap,
  HeartPulse,
  Database,
  type LucideIcon,
} from "lucide-react";

export interface Feature {
  icon: LucideIcon;
  title: string;
  description: string;
  accent: "primary" | "secondary" | "accent";
}

export const features: Feature[] = [
  {
    icon: ScanLine,
    title: "AI Food Scanner",
    description:
      "Point your camera at any meal. Our vision model identifies every item on the plate in under a second.",
    accent: "primary",
  },
  {
    icon: Flame,
    title: "Calorie Tracker",
    description:
      "Automatic calorie logging with a clean daily ring. See consumed vs. remaining at a glance.",
    accent: "accent",
  },
  {
    icon: Salad,
    title: "Nutrition Analysis",
    description:
      "Protein, carbs, fats, fibre and micronutrients — sourced from a verified database, never guessed.",
    accent: "secondary",
  },
  {
    icon: LayoutDashboard,
    title: "Health Dashboard",
    description:
      "Calories, water, sleep and weight unified in one calm, glanceable home screen.",
    accent: "primary",
  },
  {
    icon: Sparkles,
    title: "AI Insights",
    description:
      "Personalised nudges that learn your patterns and suggest small, sustainable improvements.",
    accent: "accent",
  },
  {
    icon: TrendingUp,
    title: "Progress Tracking",
    description:
      "Streaks, weekly goals and long-term trends that keep you motivated without the noise.",
    accent: "secondary",
  },
];

export interface Step {
  number: string;
  title: string;
  description: string;
}

export const steps: Step[] = [
  {
    number: "01",
    title: "Scan your food",
    description:
      "Take a photo of your plate or upload one from your gallery. No manual searching required.",
  },
  {
    number: "02",
    title: "AI recognises it",
    description:
      "CareMate's vision engine identifies each food item and matches it to our verified nutrition database.",
  },
  {
    number: "03",
    title: "See your nutrition",
    description:
      "Calories, macros and micronutrients appear instantly and sync to your daily dashboard.",
  },
];

export interface Advantage {
  icon: LucideIcon;
  title: string;
  description: string;
}

export const advantages: Advantage[] = [
  {
    icon: ShieldCheck,
    title: "Verified, never estimated",
    description:
      "Every number comes from a curated nutrition database — not a language model's best guess.",
  },
  {
    icon: Zap,
    title: "Effortlessly fast",
    description:
      "From photo to full breakdown in seconds. Logging a meal takes less time than opening a menu.",
  },
  {
    icon: HeartPulse,
    title: "Built around your health",
    description:
      "Goals adapt to you. Gentle guidance replaces guilt-driven calorie counting.",
  },
  {
    icon: Database,
    title: "Private by design",
    description:
      "Your data stays yours. On-device processing where possible and transparent controls everywhere.",
  },
];

export interface Comparison {
  label: string;
  caremate: string;
  others: string;
}

export const comparison: Comparison[] = [
  { label: "Food logging", caremate: "One photo", others: "Manual search & entry" },
  { label: "Nutrition source", caremate: "Verified database", others: "Crowd-sourced guesses" },
  { label: "Time per meal", caremate: "~3 seconds", others: "2–4 minutes" },
  { label: "AI insights", caremate: "Personalised daily", others: "Generic tips" },
  { label: "Dashboard", caremate: "Unified & calm", others: "Cluttered menus" },
  { label: "Privacy", caremate: "On-device first", others: "Cloud by default" },
];

export interface Testimonial {
  name: string;
  role: string;
  quote: string;
  rating: number;
  initials: string;
}

export const testimonials: Testimonial[] = [
  {
    name: "Aarav Mehta",
    role: "Marathon runner",
    quote:
      "I've tried five calorie apps. CareMate is the first one I actually kept using — snapping a photo is just effortless.",
    rating: 5,
    initials: "AM",
  },
  {
    name: "Sofia Rossi",
    role: "Busy parent",
    quote:
      "The verified nutrition data gives me real peace of mind. No more second-guessing what's on my kids' plates.",
    rating: 5,
    initials: "SR",
  },
  {
    name: "David Okafor",
    role: "Software engineer",
    quote:
      "The dashboard is genuinely beautiful. It feels like an Apple product — calm, fast and never nagging.",
    rating: 5,
    initials: "DO",
  },
  {
    name: "Mei Lin",
    role: "Nutrition coach",
    quote:
      "I recommend CareMate to every client now. The AI insights nudge people toward habits that actually stick.",
    rating: 5,
    initials: "ML",
  },
  {
    name: "James Carter",
    role: "Weight-loss journey",
    quote:
      "Down 9kg in four months. Seeing my streak hit 18 days kept me going more than any strict diet ever did.",
    rating: 5,
    initials: "JC",
  },
  {
    name: "Priya Nair",
    role: "Yoga instructor",
    quote:
      "Finally an app that respects a healthy relationship with food. Gentle guidance, zero guilt.",
    rating: 5,
    initials: "PN",
  },
];

export interface Faq {
  question: string;
  answer: string;
}

export const faqs: Faq[] = [
  {
    question: "How does the AI food scanner work?",
    answer:
      "Take a photo of your meal and CareMate's computer-vision model identifies each item on the plate. It then matches every food to our verified nutrition database to return accurate calories and macros — no manual searching required.",
  },
  {
    question: "Is the nutrition data accurate?",
    answer:
      "Yes. Unlike apps that let an AI estimate numbers, CareMate sources all nutrition values from a curated, verified database. The AI only handles recognition — the numbers themselves are trusted data.",
  },
  {
    question: "Is CareMate AI free?",
    answer:
      "CareMate offers a generous free plan that covers daily scanning, calorie tracking and your health dashboard. A Pro plan unlocks advanced AI insights, deeper analytics and unlimited history.",
  },
  {
    question: "Which devices are supported?",
    answer:
      "CareMate AI is available on Android via Google Play and on iPhone via the App Store. Your data syncs securely across devices.",
  },
  {
    question: "How is my data handled?",
    answer:
      "Privacy is core to CareMate. We process on-device where possible, never sell your data, and give you transparent controls to export or delete everything at any time.",
  },
  {
    question: "Can it handle mixed and home-cooked meals?",
    answer:
      "Absolutely. The scanner recognises multiple items in a single photo, and you can also describe a meal in plain language — like 'two chapatis with dal and a boiled egg' — to get an instant breakdown.",
  },
];

export interface Plan {
  name: string;
  tagline: string;
  monthly: number;
  annual: number;
  featured: boolean;
  cta: string;
  features: string[];
}

export const plans: Plan[] = [
  {
    name: "Free",
    tagline: "Everything you need to start eating smarter.",
    monthly: 0,
    annual: 0,
    featured: false,
    cta: "Get started",
    features: [
      "AI food scanner",
      "Daily calorie tracking",
      "Health dashboard",
      "Hydration & weight logging",
      "7-day history",
    ],
  },
  {
    name: "Pro",
    tagline: "Deeper insight for people serious about their goals.",
    monthly: 6,
    annual: 4,
    featured: true,
    cta: "Start free trial",
    features: [
      "Everything in Free",
      "Advanced AI insights",
      "Full macro & micronutrient analysis",
      "Unlimited history & trends",
      "Custom goals & reminders",
      "Priority support",
    ],
  },
  {
    name: "Family",
    tagline: "Keep the whole household on track together.",
    monthly: 12,
    annual: 9,
    featured: false,
    cta: "Choose Family",
    features: [
      "Everything in Pro",
      "Up to 5 member profiles",
      "Shared family dashboard",
      "Per-member goals",
      "Family progress reports",
    ],
  },
];

export interface Stat {
  value: string;
  label: string;
}

export const stats: Stat[] = [
  { value: "1M+", label: "Meals scanned" },
  { value: "98%", label: "Recognition accuracy" },
  { value: "4.9★", label: "Average rating" },
  { value: "50+", label: "Nutrients tracked" },
];
