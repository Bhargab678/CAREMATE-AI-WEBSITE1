/**
 * Hero scene configuration.
 *
 * Each entry describes one floating food: which mesh to render (`type`), where it
 * sits, how big it is, and the parameters of its idle float. Positions are hand-
 * placed so objects never overlap or collide.
 *
 * ── SWAPPING IN REAL .glb MODELS ─────────────────────────────────────────────
 * The `type` maps to a component in `foods/registry.tsx`. To use a real model,
 * either (a) replace that registry entry with a GLB-loading component, or
 * (b) add an optional `glb` path here and branch on it in `Foods.tsx`. See the
 * detailed guide at the bottom of `foods/registry.tsx`.
 */

export type FoodType =
  | "apple"
  | "avocado"
  | "banana"
  | "orange"
  | "broccoli"
  | "blueberries"
  | "salmon"
  | "eggs"
  | "almonds"
  | "spinach";

export interface FloatConfig {
  /** vertical bob */
  ampY: number;
  speedY: number;
  /** left/right drift */
  ampX: number;
  speedX: number;
  /** rotation speeds (rad/s) */
  rotY: number;
  rotX: number;
  /** unique phase so nothing moves in lockstep */
  phase: number;
}

export interface FoodConfig {
  id: string;
  type: FoodType;
  /** future: path to a .glb under /public/models to override the procedural mesh */
  glb?: string;
  position: [number, number, number];
  scale: number;
  float: FloatConfig;
}

const f = (
  ampY: number,
  speedY: number,
  ampX: number,
  speedX: number,
  rotY: number,
  rotX: number,
  phase: number
): FloatConfig => ({ ampY, speedY, ampX, speedX, rotY, rotX, phase });

export const FOODS: FoodConfig[] = [
  { id: "apple-1", type: "apple", position: [-4.6, 1.6, -1], scale: 1, float: f(0.35, 0.6, 0.25, 0.35, 0.25, 0.06, 0.0) },
  { id: "avocado-1", type: "avocado", position: [4.4, 1.9, -1.6], scale: 1.05, float: f(0.4, 0.5, 0.3, 0.3, -0.2, 0.05, 1.1) },
  { id: "banana-1", type: "banana", position: [-3.2, -1.8, 0.4], scale: 1, float: f(0.45, 0.55, 0.22, 0.4, 0.3, 0.08, 2.2) },
  { id: "orange-1", type: "orange", position: [3.1, -1.6, 0.6], scale: 0.95, float: f(0.38, 0.65, 0.28, 0.32, -0.28, 0.05, 3.0) },
  { id: "broccoli-1", type: "broccoli", position: [-5.6, -0.4, -2.4], scale: 1.1, float: f(0.3, 0.45, 0.2, 0.28, 0.22, 0.04, 0.7) },
  { id: "blueberries-1", type: "blueberries", position: [5.4, 0.2, -2.2], scale: 1, float: f(0.42, 0.6, 0.26, 0.36, 0.35, 0.07, 1.7) },
  { id: "salmon-1", type: "salmon", position: [-1.9, 2.3, -2.8], scale: 1, float: f(0.32, 0.5, 0.24, 0.3, -0.24, 0.06, 2.6) },
  { id: "eggs-1", type: "eggs", position: [1.7, -2.4, -1.2], scale: 1, float: f(0.36, 0.55, 0.2, 0.34, 0.2, 0.05, 3.4) },
  { id: "almonds-1", type: "almonds", position: [0.4, 2.6, -3.4], scale: 1, float: f(0.34, 0.48, 0.22, 0.26, 0.3, 0.06, 4.1) },
  { id: "spinach-1", type: "spinach", position: [0.2, -0.6, 1.4], scale: 1.1, float: f(0.3, 0.52, 0.18, 0.3, -0.26, 0.05, 0.4) },
];

/** Quality tiers chosen from device capability at runtime. */
export interface QualityTier {
  particles: number;
  bloom: boolean;
  dpr: [number, number];
  shadows: boolean;
}

export const QUALITY: Record<"high" | "mid" | "low", QualityTier> = {
  high: { particles: 1800, bloom: true, dpr: [1, 1.8], shadows: true },
  mid: { particles: 900, bloom: true, dpr: [1, 1.4], shadows: false },
  low: { particles: 400, bloom: false, dpr: [1, 1], shadows: false },
};

/** Brand-adjacent palette used across the scene. */
export const PALETTE = {
  navy: "#050b1a",
  navyDeep: "#03060f",
  primary: "#10b981",
  accent: "#22c55e",
  sky: "#38bdf8",
  blue: "#3b82f6",
} as const;
