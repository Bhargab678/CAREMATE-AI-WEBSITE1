import { cn } from "@/lib/utils";
import { siteConfig } from "@/lib/site";

function GooglePlayIcon() {
  return (
    <svg viewBox="0 0 512 512" className="h-6 w-6" aria-hidden="true">
      <path fill="#00D2FF" d="M47 24 289 256 47 488c-9-5-15-15-15-27V51c0-12 6-22 15-27z" />
      <path fill="#00E676" d="M47 24c5-3 11-4 17-2l286 165-63 69L47 24z" />
      <path fill="#FF3D00" d="M350 187 447 243c19 11 19 27 0 38l-97 56-63-75 63-75z" />
      <path fill="#FFC107" d="M287 325 64 490c-6 2-12 1-17-2l240-232 63 69z" />
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg viewBox="0 0 384 512" className="h-6 w-6 fill-current" aria-hidden="true">
      <path d="M318 268c-1-58 47-86 49-87-27-39-68-45-83-45-35-4-69 21-86 21-18 0-45-20-74-20-38 1-73 22-93 56-40 69-10 172 28 228 19 27 41 58 70 57 28-1 39-18 73-18 33 0 43 18 73 17 30-1 49-28 67-55 21-30 30-60 30-62-1-1-58-22-59-89zM262 84c15-19 26-45 23-71-22 1-49 15-65 34-14 16-27 43-24 68 25 2 50-13 66-31z" />
    </svg>
  );
}

interface StoreButtonProps {
  store: "google" | "apple";
  className?: string;
}

function StoreButton({ store, className }: StoreButtonProps) {
  const isGoogle = store === "google";
  const href = isGoogle ? siteConfig.links.playStore : siteConfig.links.appStore;
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "btn-focus group inline-flex h-14 items-center gap-3 rounded-2xl bg-ink px-5 text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-slate-800 hover:shadow-card",
        className
      )}
      aria-label={isGoogle ? "Get it on Google Play" : "Download on the App Store"}
    >
      {isGoogle ? <GooglePlayIcon /> : <AppleIcon />}
      <span className="flex flex-col items-start leading-none">
        <span className="text-[10px] font-medium uppercase tracking-wide text-white/70">
          {isGoogle ? "Get it on" : "Download on the"}
        </span>
        <span className="text-lg font-semibold tracking-tight">
          {isGoogle ? "Google Play" : "App Store"}
        </span>
      </span>
    </a>
  );
}

export function StoreButtons({ className }: { className?: string }) {
  return (
    <div className={cn("flex flex-col gap-3 sm:flex-row", className)}>
      <StoreButton store="google" />
      {siteConfig.appStoreLive && <StoreButton store="apple" />}
    </div>
  );
}
