import Link from "next/link";
import { Clock, ArrowUpRight } from "lucide-react";
import type { BlogPostMeta } from "@/lib/blog";
import { formatDate } from "@/lib/utils";

const gradients: Record<string, string> = {
  Nutrition: "from-primary/80 to-accent/70",
  Fitness: "from-secondary/80 to-primary/70",
  Wellness: "from-accent/80 to-secondary/70",
  Technology: "from-slate-700 to-slate-900",
  Health: "from-primary/80 to-secondary/70",
};

export function BlogCard({ post }: { post: BlogPostMeta }) {
  const gradient = gradients[post.category] ?? gradients.Health;
  return (
    <article className="card-dark card-hover group flex flex-col overflow-hidden">
      <Link href={`/blog/${post.slug}`} className="relative block">
        <div
          className={`relative flex aspect-[16/10] items-end overflow-hidden bg-gradient-to-br ${gradient} p-5`}
        >
          <div className="absolute inset-0 bg-grid-slate bg-[size:26px_26px] opacity-30" />
          <span className="relative rounded-full bg-void/70 px-3 py-1 text-xs font-semibold text-white ring-1 ring-white/20 backdrop-blur">
            {post.category}
          </span>
          <span className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-white/20 text-white opacity-0 backdrop-blur transition-all duration-300 group-hover:opacity-100">
            <ArrowUpRight className="h-4 w-4" />
          </span>
        </div>
      </Link>
      <div className="flex flex-1 flex-col p-6">
        <div className="flex items-center gap-3 text-xs text-slate-500">
          <span>{formatDate(post.date)}</span>
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" />
            {post.readingTime} min read
          </span>
        </div>
        <h3 className="mt-3 text-lg font-bold leading-snug text-white transition-colors group-hover:text-neon-cyan">
          <Link href={`/blog/${post.slug}`}>{post.title}</Link>
        </h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-400">
          {post.excerpt}
        </p>
        <div className="mt-5 flex items-center gap-2.5 border-t border-white/10 pt-4">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-primary to-neon-cyan text-[11px] font-bold text-void">
            {post.author
              .split(" ")
              .map((n) => n[0])
              .join("")
              .slice(0, 2)}
          </span>
          <span className="flex flex-col leading-tight">
            <span className="text-xs font-semibold text-white">{post.author}</span>
            <span className="text-[11px] text-slate-500">{post.authorRole}</span>
          </span>
        </div>
      </div>
    </article>
  );
}
