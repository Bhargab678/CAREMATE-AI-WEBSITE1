"use client";

import { motion } from "framer-motion";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { staggerContainer, staggerItem } from "@/components/motion/Reveal";
import { CinematicSection } from "@/components/media/CinematicSection";
import { features } from "@/lib/content";
import { cn } from "@/lib/utils";

const accentMap = {
  primary: "from-primary/25 to-primary/5 text-primary",
  secondary: "from-neon-blue/25 to-neon-blue/5 text-neon-blue",
  accent: "from-neon-cyan/25 to-neon-cyan/5 text-neon-cyan",
};

export function Features() {
  return (
    <CinematicSection id="features" video="features" tone="cyan" overlay="bg-void/82">
      <div>
        <SectionHeading
          eyebrow="Trusted features"
          title="Everything you need to eat smarter"
          description="A complete nutrition companion — from instant food recognition to a calm, unified health dashboard."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-60px" }}
          className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {features.map((feature) => (
            <motion.div
              key={feature.title}
              variants={staggerItem}
              className="glow-ring card-dark card-hover group relative overflow-hidden p-7"
            >
              <div
                className={cn(
                  "grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ring-1 ring-white/10 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-3",
                  accentMap[feature.accent]
                )}
              >
                <feature.icon className="h-6 w-6" strokeWidth={2} />
              </div>
              <h3 className="mt-5 text-lg font-bold text-white">{feature.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">
                {feature.description}
              </p>
              <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-neon-cyan/20 opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </CinematicSection>
  );
}
