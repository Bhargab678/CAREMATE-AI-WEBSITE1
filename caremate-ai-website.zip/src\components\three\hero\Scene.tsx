"use client";

import { Suspense } from "react";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import { Lighting } from "./Lighting";
import { CameraRig } from "./CameraRig";
import { Foods } from "./Foods";
import { Particles } from "./Particles";
import { AiEffects } from "./effects/AiEffects";
import { PALETTE, type QualityTier } from "./config";

export function Scene({
  quality,
  reduced,
}: {
  quality: QualityTier;
  reduced: boolean;
}) {
  return (
    <>
      <color attach="background" args={[PALETTE.navy]} />
      <fogExp2 attach="fog" args={[PALETTE.navyDeep, 0.05]} />

      <Lighting shadows={quality.shadows} />
      <CameraRig reduced={reduced} />

      <Suspense fallback={null}>
        <Foods reduced={reduced} />
      </Suspense>

      <AiEffects reduced={reduced} />
      <Particles count={quality.particles} reduced={reduced} />

      {quality.bloom && (
        <EffectComposer enableNormalPass={false} multisampling={0}>
          <Bloom
            intensity={0.7}
            luminanceThreshold={0.22}
            luminanceSmoothing={0.9}
            mipmapBlur
            radius={0.6}
          />
        </EffectComposer>
      )}
    </>
  );
}
