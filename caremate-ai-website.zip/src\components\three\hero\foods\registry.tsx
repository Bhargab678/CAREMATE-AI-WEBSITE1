"use client";

import { useMemo } from "react";
import type { FoodType } from "../config";

/*
 * Procedural, premium-looking food meshes. Each returns a <group> centred at the
 * origin, roughly 0.5–1 unit in radius, so the parent <FloatingFood> can place
 * and animate it uniformly. Materials use subtle emissive so Bloom picks up soft
 * highlights without washing the shapes out.
 *
 * See the "SWAPPING IN REAL .glb MODELS" guide at the bottom of this file.
 */

type FoodProps = { scale?: number };

function Apple({ scale = 1 }: FoodProps) {
  return (
    <group scale={scale}>
      <mesh castShadow receiveShadow scale={[1, 0.92, 1]}>
        <sphereGeometry args={[0.5, 40, 40]} />
        <meshStandardMaterial color="#e23b3b" roughness={0.28} metalness={0.05} emissive="#5c0f0f" emissiveIntensity={0.25} />
      </mesh>
      <mesh position={[0, 0.5, 0]} castShadow>
        <cylinderGeometry args={[0.03, 0.04, 0.22, 8]} />
        <meshStandardMaterial color="#6b4326" roughness={0.8} />
      </mesh>
      <mesh position={[0.14, 0.55, 0]} rotation={[0, 0, -0.7]} castShadow>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshStandardMaterial color="#3fae57" roughness={0.5} />
      </mesh>
    </group>
  );
}

function Orange({ scale = 1 }: FoodProps) {
  return (
    <group scale={scale}>
      <mesh castShadow receiveShadow>
        <sphereGeometry args={[0.5, 40, 40]} />
        <meshStandardMaterial color="#ff8c1a" roughness={0.42} metalness={0.02} emissive="#7a3a00" emissiveIntensity={0.22} />
      </mesh>
      <mesh position={[0, 0.5, 0]} castShadow>
        <cylinderGeometry args={[0.05, 0.06, 0.06, 8]} />
        <meshStandardMaterial color="#4b7d33" roughness={0.7} />
      </mesh>
    </group>
  );
}

function Avocado({ scale = 1 }: FoodProps) {
  return (
    <group scale={scale}>
      <mesh castShadow receiveShadow scale={[0.72, 1, 0.72]} position={[0, -0.05, 0]}>
        <sphereGeometry args={[0.5, 40, 40]} />
        <meshStandardMaterial color="#3c6b2f" roughness={0.5} metalness={0.05} emissive="#12240c" emissiveIntensity={0.3} />
      </mesh>
      <mesh castShadow scale={[0.5, 0.62, 0.5]} position={[0, 0.28, 0]}>
        <sphereGeometry args={[0.5, 32, 32]} />
        <meshStandardMaterial color="#4f8a3a" roughness={0.55} />
      </mesh>
    </group>
  );
}

function Banana({ scale = 1 }: FoodProps) {
  return (
    <group scale={scale} rotation={[0, 0, 0.5]}>
      <mesh castShadow receiveShadow rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.5, 0.15, 18, 40, Math.PI * 0.95]} />
        <meshStandardMaterial color="#f5cf3d" roughness={0.4} metalness={0.03} emissive="#5c4a00" emissiveIntensity={0.22} />
      </mesh>
    </group>
  );
}

function Broccoli({ scale = 1 }: FoodProps) {
  const florets = useMemo(
    () =>
      [
        [0, 0.34, 0],
        [0.22, 0.24, 0.08],
        [-0.2, 0.26, -0.06],
        [0.08, 0.28, -0.22],
        [-0.06, 0.3, 0.22],
        [0.14, 0.42, 0.02],
      ] as [number, number, number][],
    []
  );
  return (
    <group scale={scale}>
      <mesh position={[0, -0.18, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[0.12, 0.16, 0.4, 12]} />
        <meshStandardMaterial color="#bcd07f" roughness={0.75} />
      </mesh>
      {florets.map((p, i) => (
        <mesh key={i} position={p} castShadow receiveShadow>
          <icosahedronGeometry args={[0.2, 1]} />
          <meshStandardMaterial color="#2f7d3a" roughness={0.85} emissive="#0e2a12" emissiveIntensity={0.25} flatShading />
        </mesh>
      ))}
    </group>
  );
}

function Blueberries({ scale = 1 }: FoodProps) {
  const berries = useMemo(
    () =>
      [
        [0, 0, 0],
        [0.26, 0.05, 0.05],
        [-0.22, 0.08, -0.04],
        [0.06, 0.24, -0.18],
        [-0.1, -0.2, 0.16],
      ] as [number, number, number][],
    []
  );
  return (
    <group scale={scale}>
      {berries.map((p, i) => (
        <mesh key={i} position={p} castShadow receiveShadow>
          <sphereGeometry args={[0.2, 28, 28]} />
          <meshStandardMaterial color="#4257b8" roughness={0.35} metalness={0.1} emissive="#141b4d" emissiveIntensity={0.4} />
        </mesh>
      ))}
    </group>
  );
}

function Salmon({ scale = 1 }: FoodProps) {
  return (
    <group scale={scale} rotation={[0.2, 0.3, 0.1]}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[0.95, 0.22, 0.6]} />
        <meshStandardMaterial color="#ff7a66" roughness={0.5} metalness={0.05} emissive="#5c1f14" emissiveIntensity={0.2} />
      </mesh>
      {[-0.28, -0.02, 0.24].map((x, i) => (
        <mesh key={i} position={[x, 0.12, 0]} castShadow>
          <boxGeometry args={[0.08, 0.02, 0.6]} />
          <meshStandardMaterial color="#ffd8cf" roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}

function Eggs({ scale = 1 }: FoodProps) {
  return (
    <group scale={scale}>
      {[
        [-0.22, 0, 0.05],
        [0.24, -0.02, -0.06],
      ].map((p, i) => (
        <mesh key={i} position={p as [number, number, number]} scale={[0.72, 1, 0.72]} castShadow receiveShadow>
          <sphereGeometry args={[0.34, 32, 32]} />
          <meshStandardMaterial color="#f6efe2" roughness={0.35} metalness={0.02} emissive="#3a3428" emissiveIntensity={0.15} />
        </mesh>
      ))}
    </group>
  );
}

function Almonds({ scale = 1 }: FoodProps) {
  const nuts = useMemo(
    () =>
      [
        { p: [0, 0.05, 0], r: [0, 0, 0.3] },
        { p: [0.28, -0.06, 0.1], r: [0.2, 0.4, -0.4] },
        { p: [-0.24, -0.04, -0.08], r: [-0.2, -0.3, 0.5] },
      ] as { p: [number, number, number]; r: [number, number, number] }[],
    []
  );
  return (
    <group scale={scale}>
      {nuts.map((n, i) => (
        <mesh key={i} position={n.p} rotation={n.r} scale={[0.34, 0.2, 0.6]} castShadow receiveShadow>
          <sphereGeometry args={[0.5, 24, 24]} />
          <meshStandardMaterial color="#d9a86b" roughness={0.6} emissive="#3a2712" emissiveIntensity={0.18} />
        </mesh>
      ))}
    </group>
  );
}

function Spinach({ scale = 1 }: FoodProps) {
  const leaves = useMemo(
    () =>
      [
        { p: [0, 0, 0], r: [0.2, 0, 0.1] },
        { p: [0.2, 0.06, -0.1], r: [-0.3, 0.6, -0.2] },
        { p: [-0.18, -0.04, 0.12], r: [0.4, -0.5, 0.3] },
      ] as { p: [number, number, number]; r: [number, number, number] }[],
    []
  );
  return (
    <group scale={scale}>
      {leaves.map((l, i) => (
        <mesh key={i} position={l.p} rotation={l.r} scale={[0.5, 0.06, 0.72]} castShadow receiveShadow>
          <sphereGeometry args={[0.5, 20, 12]} />
          <meshStandardMaterial color="#2f8f43" roughness={0.7} emissive="#0e2c15" emissiveIntensity={0.28} flatShading />
        </mesh>
      ))}
    </group>
  );
}

/**
 * Registry: maps a FoodType to its mesh component.
 * This single object is the seam you replace to use real models.
 */
export const FOOD_REGISTRY: Record<FoodType, (props: FoodProps) => React.JSX.Element> = {
  apple: Apple,
  avocado: Avocado,
  banana: Banana,
  orange: Orange,
  broccoli: Broccoli,
  blueberries: Blueberries,
  salmon: Salmon,
  eggs: Eggs,
  almonds: Almonds,
  spinach: Spinach,
};

/* ─────────────────────────────────────────────────────────────────────────────
 * SWAPPING IN REAL .glb MODELS
 * ─────────────────────────────────────────────────────────────────────────────
 * 1. Put optimized models in `public/models/` (e.g. apple.glb). Draco/Meshopt
 *    compress them and keep each well under ~500 KB for fast loads.
 *
 * 2. Create a GLB component, e.g.:
 *
 *      import { useGLTF } from "@react-three/drei";
 *      function AppleGLB({ scale = 1 }: { scale?: number }) {
 *        const { scene } = useGLTF("/models/apple.glb");
 *        const cloned = useMemo(() => scene.clone(true), [scene]);
 *        // ensure shadows:
 *        cloned.traverse((o) => {
 *          if ((o as THREE.Mesh).isMesh) { o.castShadow = true; o.receiveShadow = true; }
 *        });
 *        return <primitive object={cloned} scale={scale} />;
 *      }
 *      useGLTF.preload("/models/apple.glb");
 *
 * 3. Replace the map entry: `apple: AppleGLB`. Nothing else changes — the scene,
 *    floating animation, lighting, shadows and bloom all keep working.
 *
 * Wrap <Foods> in <Suspense> (already done in HeroCanvas) so models stream in
 * without blocking the first paint.
 * ───────────────────────────────────────────────────────────────────────────── */
