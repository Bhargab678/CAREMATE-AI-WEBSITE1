"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X } from "lucide-react";
import { BlogCard } from "@/components/blog/BlogCard";
import type { BlogPostMeta } from "@/lib/blog";
import { cn } from "@/lib/utils";

export function BlogListing({
  posts,
  categories,
}: {
  posts: BlogPostMeta[];
  categories: string[];
}) {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState("All");

  const allCategories = ["All", ...categories];

  const filtered = useMemo(() => {
    return posts.filter((post) => {
      const matchesCategory = active === "All" || post.category === active;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        post.title.toLowerCase().includes(q) ||
        post.excerpt.toLowerCase().includes(q) ||
        post.tags.some((t) => t.toLowerCase().includes(q));
      return matchesCategory && matchesQuery;
    });
  }, [posts, active, query]);

  return (
    <div>
      <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search articles…"
            aria-label="Search articles"
            className="btn-focus h-11 w-full rounded-full border border-white/10 bg-white/5 pl-11 pr-10 text-sm text-white outline-none backdrop-blur transition-colors placeholder:text-slate-500 focus:border-neon-cyan/60"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              aria-label="Clear search"
              className="absolute right-3 top-1/2 grid h-6 w-6 -translate-y-1/2 place-items-center rounded-full text-slate-500 hover:bg-white/10"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
          {allCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActive(cat)}
              className={cn(
                "btn-focus shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-all",
                active === cat
                  ? "border-neon-cyan/60 bg-gradient-to-r from-primary to-neon-cyan text-void shadow-[0_0_24px_-6px_rgba(34,211,238,0.7)]"
                  : "border-white/10 bg-white/5 text-slate-400 backdrop-blur hover:border-white/25 hover:text-white"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence mode="popLayout">
        {filtered.length ? (
          <motion.div
            layout
            className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          >
            {filtered.map((post) => (
              <motion.div
                key={post.slug}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.35 }}
              >
                <BlogCard post={post} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-16 text-center"
          >
            <p className="text-lg font-semibold text-white">No articles found</p>
            <p className="mt-1 text-slate-400">
              Try a different search term or category.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
