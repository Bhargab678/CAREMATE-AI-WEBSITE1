"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ScanLine, ArrowRight } from "lucide-react";
import { CinematicSection } from "@/components/media/CinematicSection";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/motion/Reveal";
import { PhoneFrame } from "@/components/phone/PhoneFrame";
import { ScanScreen } from "@/components/phone/AppScreens";
import { siteConfig } from "@/lib/site";

const READOUT = [
  { k: "Calories", v: "412 kcal" },
  { k: "Protein", v: "24 g" },
  { k: "Carbs", v: "38 g" },
  { k: "Fat", v: "17 g" },
];

export function ScannerCinematic() {
  const reduce = useReducedMotion();

  return (
    <CinematicSection
      id="scanner"
      video="scanner"
      tone="emerald"
      overlay="bg-void/76"
    >
      <div className="grid items-center gap-14 lg:grid-cols-2">
        <div>
          <Reveal>
            <span className="eyebrow">
              <ScanLine className="h-3.5 w-3.5 text-neon-cyan" />
              AI Food Scanner
            </span>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="h-section mt-5">
              Scan any meal.{" "}
              <span className="text-gradient">Instantly.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="p-section mt-4 max-w-xl">
              Point your camera at the plate. Vision AI identifies every item and
              pulls real numbers from our verified nutrition database — never a
              guess, never an estimate.
            </p>
          </Reveal>

          <Reveal delay={0.15}>
            <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {READOUT.map((r, i) => (
                <motion.div
                  key={r.k}
                  initial={{ opacity: 0, y: 14 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + i * 0.09 }}
                  className="rounded-2xl border border-white/10 bg-white/[0.04] p-3 text-center backdrop-blur"
                >
                  <p className="text-lg font-extrabold text-white">{r.v}</p>
                  <p className="mt-0.5 text-[10px] uppercase tracking-widest text-slate-500">
                    {r.k}
                  </p>
                </motion.div>
              ))}
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <Button
              href={siteConfig.links.playStore}
              external
              size="lg"
              className="mt-8"
            >
              Try it now <ArrowRight className="h-4 w-4" />
            </Button>
          </Reveal>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto"
        >
          <motion.div
            animate={reduce ? undefined : { y: [0, -12, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          >
            <PhoneFrame>
              <ScanScreen />
            </PhoneFrame>
          </motion.div>

          {/* health score badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6 }}
            className="absolute -right-2 top-24 z-20 hidden rounded-2xl border border-white/15 bg-void/80 px-4 py-3 backdrop-blur-xl sm:block"
          >
            <p className="text-[10px] uppercase tracking-widest text-slate-500">
              Health score
            </p>
            <p className="bg-gradient-to-r from-primary to-neon-cyan bg-clip-text text-2xl font-extrabold text-transparent">
              92
            </p>
          </motion.div>
        </motion.div>
      </div>
    </CinematicSection>
  );
}
