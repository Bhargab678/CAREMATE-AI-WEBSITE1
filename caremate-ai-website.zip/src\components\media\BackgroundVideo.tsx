"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { useReducedMotion } from "framer-motion";
import { mediaConfig, type VideoKey } from "@/lib/media";
import { cn } from "@/lib/utils";

interface BackgroundVideoProps {
  /** Key into mediaConfig.videos, or pass explicit srcs below. */
  video?: VideoKey;
  webm?: string;
  mp4?: string;
  poster?: string;
  /** Overlay tint above the video for text contrast (e.g. "bg-black/50"). */
  overlayClassName?: string;
  className?: string;
  /** Rendered behind the video — the always-visible graceful fallback. */
  fallback?: ReactNode;
  /** Hero-style: preload eagerly and mount immediately (above the fold). */
  eager?: boolean;
}

/**
 * Performance-first background video:
 * - Lazy-mounts only when scrolled near the viewport (IntersectionObserver).
 * - Plays only while visible; pauses off-screen to save battery/CPU.
 * - WebM primary + MP4 fallback, muted, looped, inline autoplay, no controls.
 * - Honors prefers-reduced-motion (renders the static fallback instead).
 * - Disabled globally until mediaConfig.videoBackgrounds is true, so there are
 *   no 404s or empty frames before you add the asset files.
 */
export function BackgroundVideo({
  video,
  webm,
  mp4,
  poster,
  overlayClassName,
  className,
  fallback,
  eager = false,
}: BackgroundVideoProps) {
  const reduce = useReducedMotion();
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [mounted, setMounted] = useState(eager);

  const src = video ? mediaConfig.videos[video] : { webm, mp4, poster };
  const enabled =
    mediaConfig.videoBackgrounds && !reduce && Boolean(src.webm || src.mp4);

  useEffect(() => {
    if (!enabled || eager) return;
    const el = containerRef.current;
    if (!el || typeof IntersectionObserver === "undefined") {
      setMounted(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setMounted(true);
            videoRef.current?.play().catch(() => {});
          } else {
            videoRef.current?.pause();
          }
        }
      },
      { rootMargin: "200px", threshold: 0.01 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [enabled, eager]);

  return (
    <div
      ref={containerRef}
      aria-hidden
      className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)}
    >
      {/* Always-present graceful fallback */}
      {fallback && <div className="absolute inset-0">{fallback}</div>}

      {enabled && mounted && (
        <video
          ref={videoRef}
          className="absolute inset-0 h-full w-full object-cover [transform:translateZ(0)]"
          autoPlay
          muted
          loop
          playsInline
          preload={eager ? "auto" : "none"}
          poster={src.poster}
        >
          {src.webm && <source src={src.webm} type="video/webm" />}
          {src.mp4 && <source src={src.mp4} type="video/mp4" />}
        </video>
      )}

      {overlayClassName && <div className={cn("absolute inset-0", overlayClassName)} />}
    </div>
  );
}
