"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import type { Group } from "three";
import { FOODS, type FoodConfig } from "./config";
import { FOOD_REGISTRY } from "./foods/registry";

function FloatingFood({ cfg, reduced }: { cfg: FoodConfig; reduced: boolean }) {
  const ref = useRef<Group>(null);
  const Mesh = FOOD_REGISTRY[cfg.type];
  const [bx, by, bz] = cfg.position;
  const { ampY, speedY, ampX, speedX, rotY, rotX, phase } = cfg.float;

  useFrame((state) => {
    const g = ref.current;
    if (!g) return;
    if (reduced) {
      g.position.set(bx, by, bz);
      return;
    }
    const t = state.clock.elapsedTime;
    g.position.y = by + Math.sin(t * speedY + phase) * ampY;
    g.position.x = bx + Math.sin(t * speedX + phase * 1.3) * ampX;
    g.position.z = bz + Math.cos(t * speedX * 0.7 + phase) * ampX * 0.4;
    g.rotation.y += rotY * 0.01;
    g.rotation.x = Math.sin(t * 0.3 + phase) * rotX;
  });

  return (
    <group ref={ref} position={cfg.position}>
      <Mesh scale={cfg.scale} />
    </group>
  );
}

export function Foods({ reduced }: { reduced: boolean }) {
  return (
    <group>
      {FOODS.map((cfg) => (
        <FloatingFood key={cfg.id} cfg={cfg} reduced={reduced} />
      ))}
    </group>
  );
}
