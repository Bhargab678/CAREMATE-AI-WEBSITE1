import type { Metadata } from "next";
import Link from "next/link";
import { Clock, ArrowRight } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BlogListing } from "@/components/blog/BlogListing";
import { Reveal } from "@/components/motion/Reveal";
import { getAllPosts, getCategories, getFeaturedPost } from "@/lib/blog";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Evidence-based articles on nutrition, calorie tracking, healthy habits and mindful eating from the CareMate AI team.",
  alternates: { canonical: "/blog" },
};

export default function BlogPage() {
  const posts = getAllPosts();
  const categories = getCategories();
  const featured = getFeaturedPost();

  return (
    <>
      <PageHeader
        eyebrow="CareMate Journal"
        title="Insights for a healthier life"
        description="Practical, science-backed guidance on nutrition, habits and living well — written by our editorial team."
      />

      <section className="pb-24">
        <div className="container">
          {featured && (
            <Reveal>
              <Link
                href={`/blog/${featured.slug}`}
                className="group mb-14 grid overflow-hidden card-dark transition-all hover:border-white/20 lg:grid-cols-2"
              >
                <div className="relative flex min-h-[240px] items-end bg-gradient-to-br from-primary/85 via-accent/75 to-secondary/80 p-8">
                  <div className="absolute inset-0 bg-grid-slate bg-[size:28px_28px] opacity-30" />
                  <span className="relative rounded-full bg-void/70 px-3 py-1 text-xs font-semibold text-white ring-1 ring-white/20">
                    Featured · {featured.category}
                  </span>
                </div>
                <div className="flex flex-col justify-center p-8 lg:p-10">
                  <div className="flex items-center gap-3 text-xs text-slate-500">
                    <span>{formatDate(featured.date)}</span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {featured.readingTime} min read
                    </span>
                  </div>
                  <h2 className="mt-3 text-2xl font-bold leading-snug text-white transition-colors group-hover:text-neon-cyan sm:text-3xl">
                    {featured.title}
                  </h2>
                  <p className="mt-3 leading-relaxed text-slate-400">
                    {featured.excerpt}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-neon-cyan transition-all group-hover:gap-2.5">
                    Read article <ArrowRight className="h-4 w-4" />
                  </span>
                </div>
              </Link>
            </Reveal>
          )}

          <BlogListing posts={posts} categories={categories} />
        </div>
      </section>
    </>
  );
}
