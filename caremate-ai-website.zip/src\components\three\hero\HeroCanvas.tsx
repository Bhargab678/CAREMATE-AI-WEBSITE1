"use client";

import { useEffect, useMemo, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { useReducedMotion } from "framer-motion";
import { Scene } from "./Scene";
import { QUALITY } from "./config";
import { detectQuality } from "./utils";

/**
 * Fullscreen R3F hero background. Sits behind the hero content (pointer-events
 * none), picks a quality tier from the device, and honours prefers-reduced-motion.
 * Rendered via next/dynamic with `ssr: false` from Hero.tsx.
 */
/** Feature-detect a usable WebGL context (some devices/browsers block it). */
function webglAvailable(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const canvas = document.createElement("canvas");
    return !!(
      window.WebGLRenderingContext &&
      (canvas.getContext("webgl") || canvas.getContext("experimental-webgl"))
    );
  } catch {
    return false;
  }
}

export default function HeroCanvas() {
  const reduced = useReducedMotion() ?? false;
  const [tier, setTier] = useState<"high" | "mid" | "low">("mid");
  const [supported, setSupported] = useState(true);

  useEffect(() => {
    if (!webglAvailable()) {
      setSupported(false);
      return;
    }
    setTier(detectQuality());
  }, []);

  const quality = useMemo(() => {
    const q = QUALITY[tier];
    // Reduced motion: keep it lightweight and calm.
    return reduced ? { ...q, bloom: false, particles: Math.min(q.particles, 300) } : q;
  }, [tier, reduced]);

  // No WebGL → render nothing; the hero's gradient scrims provide the backdrop.
  if (!supported) return null;

  return (
    <Canvas
      shadows={quality.shadows ? "soft" : false}
      dpr={quality.dpr}
      gl={{
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
        stencil: false,
        depth: true,
        failIfMajorPerformanceCaveat: false,
      }}
      camera={{ position: [0, 0, 9], fov: 42, near: 0.1, far: 60 }}
      frameloop={reduced ? "demand" : "always"}
      style={{ pointerEvents: "none" }}
      onCreated={({ gl }) => {
        // If the GPU context is lost, don't let it bubble into a page crash.
        gl.domElement.addEventListener(
          "webglcontextlost",
          (e) => e.preventDefault(),
          false
        );
      }}
    >
      <Scene quality={quality} reduced={reduced} />
    </Canvas>
  );
}
