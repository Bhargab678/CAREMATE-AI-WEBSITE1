"use client";

import { useEffect } from "react";
import Lenis from "lenis";
import { useReducedMotion } from "framer-motion";

/**
 * Lenis smooth scrolling, synced to the rAF loop and to GSAP ScrollTrigger when
 * present. Disabled entirely under prefers-reduced-motion so native scrolling
 * (and assistive tech behaviour) is untouched.
 */
export function SmoothScroll() {
  const reduce = useReducedMotion();

  useEffect(() => {
    if (reduce) return;

    const lenis = new Lenis({
      duration: 1.1,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
      touchMultiplier: 1.6,
    });

    let rafId = 0;
    const raf = (time: number) => {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    };
    rafId = requestAnimationFrame(raf);

    // Keep ScrollTrigger in sync if it's loaded on the page.
    let cleanupST: (() => void) | undefined;
    (async () => {
      try {
        const { ScrollTrigger } = await import("gsap/ScrollTrigger");
        const onScroll = () => ScrollTrigger.update();
        lenis.on("scroll", onScroll);
        cleanupST = () => lenis.off("scroll", onScroll);
      } catch {
        /* ScrollTrigger not present — nothing to sync */
      }
    })();

    return () => {
      cancelAnimationFrame(rafId);
      cleanupST?.();
      lenis.destroy();
    };
  }, [reduce]);

  return null;
}
