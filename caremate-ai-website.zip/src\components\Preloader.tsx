"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";

export function Preloader() {
  const [done, setDone] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    // Skip the intro if the user has already seen it this session.
    if (sessionStorage.getItem("cm_preloaded")) {
      setDone(true);
      return;
    }
    const minTime = reduce ? 250 : 1500;
    const start = performance.now();

    const finish = () => {
      const elapsed = performance.now() - start;
      const wait = Math.max(0, minTime - elapsed);
      window.setTimeout(() => {
        sessionStorage.setItem("cm_preloaded", "1");
        setDone(true);
      }, wait);
    };

    if (document.readyState === "complete") finish();
    else window.addEventListener("load", finish, { once: true });

    // Safety timeout so we never trap the user behind the loader.
    const hard = window.setTimeout(() => setDone(true), 3500);
    return () => window.clearTimeout(hard);
  }, [reduce]);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          key="preloader"
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-void"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          aria-hidden="true"
        >
          {/* ambient glow */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            <div className="absolute left-1/2 top-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-tr from-primary/20 via-sky-300/20 to-secondary/20 blur-3xl" />
          </div>

          <motion.div
            initial={{ scale: 0.6, opacity: 0, y: 8 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="relative"
          >
            <motion.div
              animate={reduce ? undefined : { y: [0, -8, 0] }}
              transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/logo.png"
                alt="CareMate AI"
                width={92}
                height={92}
                className="h-[92px] w-[92px] rounded-[24%] object-contain drop-shadow-[0_12px_34px_rgba(34,211,238,0.35)]"
              />
            </motion.div>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.5 }}
            className="mt-6 font-display text-lg font-extrabold tracking-tight text-white"
          >
            CareMate AI
          </motion.p>

          {/* progress bar */}
          <div className="mt-5 h-1 w-40 overflow-hidden rounded-full bg-white/10">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-primary via-neon-cyan to-neon-purple"
              initial={{ x: "-100%" }}
              animate={{ x: "0%" }}
              transition={{ duration: reduce ? 0.25 : 1.4, ease: "easeInOut" }}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
