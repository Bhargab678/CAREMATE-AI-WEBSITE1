"use client";

import { motion, useReducedMotion } from "framer-motion";
import {
  Camera,
  ImageIcon,
  Sparkles,
  Home,
  LineChart,
  User,
  Bell,
  Flame,
  Droplet,
} from "lucide-react";

/* ---------------------------------- chrome --------------------------------- */

function StatusBar({ time = "11:23" }: { time?: string }) {
  return (
    <div className="flex items-center justify-between px-5 pt-3 text-[11px] font-semibold text-white/90">
      <span>{time}</span>
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] tracking-tight">5G</span>
        <span className="flex items-end gap-0.5">
          <span className="h-2 w-0.5 rounded-sm bg-white/80" />
          <span className="h-2.5 w-0.5 rounded-sm bg-white/80" />
          <span className="h-3 w-0.5 rounded-sm bg-white/80" />
          <span className="h-3.5 w-0.5 rounded-sm bg-white/40" />
        </span>
        <span className="ml-1 h-2.5 w-4 rounded-sm border border-white/60">
          <span className="block h-full w-2/3 rounded-[1px] bg-white/80" />
        </span>
      </div>
    </div>
  );
}

function BottomNav({ active = "home" }: { active?: "home" | "chart" | "profile" }) {
  const cls = (id: string) =>
    active === id ? "text-white" : "text-white/35";
  return (
    <div className="absolute inset-x-0 bottom-0 z-10">
      <div className="relative mx-3 mb-3 flex items-center justify-between rounded-3xl bg-white/5 px-7 py-3.5 backdrop-blur">
        <Home className={`h-5 w-5 ${cls("home")}`} />
        <LineChart className={`h-5 w-5 ${cls("chart")}`} />
        <span className="w-10" />
        <User className={`h-5 w-5 ${cls("profile")}`} />
        <div className="absolute -top-6 left-1/2 grid h-14 w-14 -translate-x-1/2 place-items-center rounded-full bg-white shadow-lg">
          <Camera className="h-6 w-6 text-black" />
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- screens --------------------------------- */

export function ScanScreen() {
  return (
    <div className="flex h-full flex-col bg-black text-white">
      <StatusBar time="11:23" />
      <div className="flex-1 overflow-hidden px-5 pt-5">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-white/45">
          Verified Nutrition
        </p>
        <h3 className="mt-1 text-3xl font-extrabold tracking-tight">Scan</h3>

        <div className="mt-4 rounded-3xl bg-white/[0.04] p-4">
          <p className="text-[11px] leading-relaxed text-white/55">
            Photograph your plate. Foods are identified from the image; nutrition
            comes from our verified database — never estimated.
          </p>
          <div className="mt-3 flex gap-2">
            <div className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-white py-2.5 text-[11px] font-bold text-black">
              <Camera className="h-3.5 w-3.5" /> Take photo
            </div>
            <div className="flex flex-1 items-center justify-center gap-1.5 rounded-full border border-white/15 py-2.5 text-[11px] font-semibold">
              <ImageIcon className="h-3.5 w-3.5" /> Upload
            </div>
          </div>

          <motion.div
            className="mt-3 overflow-hidden rounded-2xl bg-white"
            initial={{ scale: 0.96, opacity: 0.6 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="relative flex aspect-[4/3] items-center justify-center bg-gradient-to-br from-amber-200 via-orange-300 to-yellow-400">
              <span className="text-5xl" role="img" aria-label="mango">🥭</span>
              <motion.div
                aria-hidden
                className="absolute inset-x-0 h-[2px] bg-primary/80 shadow-[0_0_12px_2px] shadow-primary"
                initial={{ top: "8%" }}
                animate={{ top: ["8%", "88%", "8%"] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
          </motion.div>

          <p className="mt-3 text-center text-[9px] font-semibold uppercase tracking-[0.2em] text-white/35">
            — or describe it —
          </p>
          <div className="mt-2 rounded-2xl bg-black/60 px-3 py-2.5 text-[10px] text-white/40">
            e.g. two chapatis with dal and a boiled egg
          </div>
          <div className="mt-2 flex items-center justify-center gap-1.5 rounded-full border border-white/10 py-2.5 text-[11px] font-semibold text-white/80">
            <Sparkles className="h-3.5 w-3.5 text-primary" /> Calculate nutrition
          </div>
        </div>
      </div>
      <BottomNav active="home" />
    </div>
  );
}

export function DashboardScreen() {
  const reduce = useReducedMotion();
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const progress = 360 / 2200;

  return (
    <div className="flex h-full flex-col bg-black text-white">
      <StatusBar time="11:24" />
      <div className="flex-1 overflow-hidden px-5 pt-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-[9px] font-semibold uppercase tracking-[0.18em] text-white/45">
              Good evening · Tue 21 Jul
            </p>
            <h3 className="mt-1 text-3xl font-extrabold tracking-tight">Alex</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-white/[0.06]">
              <Bell className="h-3.5 w-3.5" />
            </span>
            <span className="h-8 w-8 rounded-full bg-white" />
          </div>
        </div>

        <div className="mt-4 rounded-3xl bg-white/[0.04] p-5">
          <p className="text-center text-[9px] font-semibold uppercase tracking-[0.2em] text-white/45">
            Today&apos;s Calories
          </p>
          <div className="relative mx-auto mt-3 grid h-32 w-32 place-items-center">
            <svg viewBox="0 0 128 128" className="h-full w-full -rotate-90">
              <circle
                cx="64"
                cy="64"
                r={radius}
                fill="none"
                stroke="rgba(255,255,255,0.08)"
                strokeWidth="9"
              />
              <motion.circle
                cx="64"
                cy="64"
                r={radius}
                fill="none"
                stroke="white"
                strokeWidth="9"
                strokeLinecap="round"
                strokeDasharray={circumference}
                initial={{ strokeDashoffset: circumference }}
                whileInView={{
                  strokeDashoffset: reduce
                    ? circumference * (1 - progress)
                    : circumference * (1 - progress),
                }}
                viewport={{ once: true }}
                transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-3xl font-extrabold leading-none">360</span>
              <span className="text-[9px] text-white/45">of 2200 kcal</span>
            </div>
          </div>
          <div className="mt-4 flex items-center justify-around border-t border-white/5 pt-3 text-center">
            <div>
              <p className="text-[8px] uppercase tracking-widest text-white/40">
                Consumed
              </p>
              <p className="text-xl font-extrabold">360</p>
            </div>
            <span className="h-8 w-px bg-white/10" />
            <div>
              <p className="text-[8px] uppercase tracking-widest text-white/40">
                Remaining
              </p>
              <p className="text-xl font-extrabold">1840</p>
            </div>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2.5">
          <div className="rounded-2xl bg-white/[0.04] p-3">
            <Flame className="h-4 w-4 text-white/70" />
            <p className="mt-2 text-lg font-extrabold">
              360 <span className="text-[10px] font-medium text-white/45">kcal</span>
            </p>
            <p className="text-[10px] text-white/45">Calories</p>
          </div>
          <div className="rounded-2xl bg-white/[0.04] p-3">
            <Droplet className="h-4 w-4 text-white/70" />
            <p className="mt-2 text-lg font-extrabold">
              1.8 <span className="text-[10px] font-medium text-white/45">L</span>
            </p>
            <p className="text-[10px] text-white/45">Water</p>
          </div>
        </div>
      </div>
      <BottomNav active="home" />
    </div>
  );
}

export function ProgressScreen() {
  const days = [
    { d: "M", on: true },
    { d: "T", on: true },
    { d: "W", on: true },
    { d: "T", on: true },
    { d: "F", on: true },
    { d: "S", on: false },
    { d: "S", on: false },
  ];
  const rings = [
    { v: 72, label: "Today" },
    { v: 64, label: "This week" },
    { v: 50, label: "Goals" },
  ];
  return (
    <div className="flex h-full flex-col bg-black text-white">
      <StatusBar time="11:22" />
      <div className="flex-1 overflow-hidden px-5 pt-5">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-white/45">
          Analytics
        </p>
        <h3 className="mt-1 text-3xl font-extrabold tracking-tight">Progress</h3>

        <div className="mt-3 flex rounded-full bg-white/[0.06] p-1 text-[11px] font-semibold">
          <span className="flex-1 rounded-full bg-white py-1.5 text-center text-black">
            Weekly
          </span>
          <span className="flex-1 py-1.5 text-center text-white/50">Monthly</span>
        </div>

        <div className="mt-3 rounded-3xl bg-white/[0.04] p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[8px] uppercase tracking-widest text-white/40">
                Current streak
              </p>
              <p className="text-2xl font-extrabold">
                12 <span className="text-xs font-medium text-white/45">days</span>
              </p>
            </div>
            <div className="text-right">
              <p className="text-[8px] uppercase tracking-widest text-white/40">
                Best
              </p>
              <p className="text-lg font-extrabold">18</p>
            </div>
          </div>
          <div className="mt-3 flex justify-between">
            {days.map((day, i) => (
              <div key={i} className="flex flex-col items-center gap-1">
                <motion.span
                  className={`grid h-6 w-6 place-items-center rounded-full text-[10px] font-bold ${
                    day.on ? "bg-white text-black" : "border border-white/15 text-white/30"
                  }`}
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06, type: "spring", stiffness: 260 }}
                >
                  {day.on ? "✓" : ""}
                </motion.span>
                <span className="text-[8px] text-white/40">{day.d}</span>
              </div>
            ))}
          </div>
        </div>

        <p className="mt-4 text-[9px] font-semibold uppercase tracking-[0.2em] text-white/40">
          Completion
        </p>
        <h4 className="text-lg font-bold">Goal progress</h4>
        <div className="mt-2 flex justify-around rounded-3xl bg-white/[0.04] p-4">
          {rings.map((ring) => {
            const r = 22;
            const c = 2 * Math.PI * r;
            return (
              <div key={ring.label} className="flex flex-col items-center gap-1.5">
                <div className="relative grid h-14 w-14 place-items-center">
                  <svg viewBox="0 0 56 56" className="h-full w-full -rotate-90">
                    <circle cx="28" cy="28" r={r} fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="5" />
                    <motion.circle
                      cx="28"
                      cy="28"
                      r={r}
                      fill="none"
                      stroke="white"
                      strokeWidth="5"
                      strokeLinecap="round"
                      strokeDasharray={c}
                      initial={{ strokeDashoffset: c }}
                      whileInView={{ strokeDashoffset: c * (1 - ring.v / 100) }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.2, ease: "easeOut" }}
                    />
                  </svg>
                  <span className="absolute text-[11px] font-bold">{ring.v}%</span>
                </div>
                <span className="text-[8px] text-white/45">{ring.label}</span>
              </div>
            );
          })}
        </div>
      </div>
      <BottomNav active="chart" />
    </div>
  );
}

export const appScreens = {
  scan: ScanScreen,
  dashboard: DashboardScreen,
  progress: ProgressScreen,
};
