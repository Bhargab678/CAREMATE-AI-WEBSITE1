"use client";

import { useState, type FormEvent } from "react";
import { Send, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/Button";

type Status = "idle" | "submitting" | "success";

export function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus("submitting");
    // Placeholder: wire this to your email service or API route.
    setTimeout(() => setStatus("success"), 900);
  };

  if (status === "success") {
    return (
      <div className="flex flex-col items-center justify-center rounded-3xl border border-primary/20 bg-primary/5 p-10 text-center">
        <CheckCircle2 className="h-12 w-12 text-primary" />
        <h3 className="mt-4 text-xl font-bold text-white">Message sent!</h3>
        <p className="mt-2 max-w-sm text-slate-400">
          Thanks for reaching out. Our team will get back to you within 1–2
          business days.
        </p>
        <button
          onClick={() => setStatus("idle")}
          className="btn-focus mt-6 rounded-full text-sm font-semibold text-neon-cyan hover:underline"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form
      onSubmit={onSubmit}
      className="card-dark p-6 sm:p-8"
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" htmlFor="name">
          <input
            id="name"
            name="name"
            required
            placeholder="Jane Doe"
            className="input"
          />
        </Field>
        <Field label="Email" htmlFor="email">
          <input
            id="email"
            name="email"
            type="email"
            required
            placeholder="jane@example.com"
            className="input"
          />
        </Field>
      </div>
      <div className="mt-5">
        <Field label="Subject" htmlFor="subject">
          <input
            id="subject"
            name="subject"
            required
            placeholder="How can we help?"
            className="input"
          />
        </Field>
      </div>
      <div className="mt-5">
        <Field label="Message" htmlFor="message">
          <textarea
            id="message"
            name="message"
            required
            rows={5}
            placeholder="Tell us a bit more…"
            className="input resize-none"
          />
        </Field>
      </div>

      <Button
        type="submit"
        size="lg"
        className="mt-6 w-full"
        disabled={status === "submitting"}
      >
        {status === "submitting" ? "Sending…" : "Send message"}
        <Send className="h-4 w-4" />
      </Button>

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border-radius: 0.9rem;
          border: 1px solid rgba(255,255,255,0.12);
          background: rgba(255,255,255,0.04);
          padding: 0.75rem 1rem;
          font-size: 0.95rem;
          color: #ffffff;
          transition: all 0.2s;
          outline: none;
        }
        :global(.input:focus) {
          border-color: rgba(34,211,238,0.7);
          background: rgba(255,255,255,0.07);
          box-shadow: 0 0 0 3px rgba(34,211,238,0.18);
        }
        :global(.input::placeholder) {
          color: #64748b;
        }
      `}</style>
    </form>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
}) {
  return (
    <label htmlFor={htmlFor} className="block">
      <span className="mb-1.5 block text-sm font-semibold text-white">{label}</span>
      {children}
    </label>
  );
}
