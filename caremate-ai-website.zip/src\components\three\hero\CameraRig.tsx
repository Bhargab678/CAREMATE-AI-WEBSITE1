"use client";

import { useThree, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { usePointer } from "./hooks/usePointer";

/**
 * Very subtle cinematic camera motion: a slow time-based drift plus a small
 * parallax that follows the pointer. All movement is damped, so there is never
 * any shake or snapping. Reduced motion pins the camera to its base position.
 */
export function CameraRig({ reduced }: { reduced: boolean }) {
  const { camera } = useThree();
  const pointer = usePointer();
  const base = new THREE.Vector3(0, 0, 9);
  const target = new THREE.Vector3();

  useFrame((state, delta) => {
    const t = state.clock.elapsedTime;
    if (reduced) {
      camera.position.lerp(base, 0.1);
      camera.lookAt(0, 0, 0);
      return;
    }
    const px = pointer.current.x;
    const py = pointer.current.y;

    target.set(
      base.x + Math.sin(t * 0.12) * 0.6 + px * 0.8,
      base.y + Math.cos(t * 0.1) * 0.4 - py * 0.5,
      base.z + Math.sin(t * 0.08) * 0.3
    );

    const k = 1 - Math.pow(0.0015, delta); // frame-rate independent damping
    camera.position.lerp(target, k);
    camera.lookAt(0, 0, 0);
  });

  return null;
}
