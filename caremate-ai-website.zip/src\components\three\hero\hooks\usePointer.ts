"use client";

import { useEffect, useRef } from "react";

/**
 * Tracks a normalized pointer position in [-1, 1] on both axes, with mouse and
 * touch support. Returns a ref (not state) so consumers can read it inside
 * useFrame without triggering React re-renders — key for a smooth 60 FPS loop.
 */
export function usePointer() {
  const pointer = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const setFrom = (clientX: number, clientY: number) => {
      pointer.current.x = (clientX / window.innerWidth) * 2 - 1;
      pointer.current.y = (clientY / window.innerHeight) * 2 - 1;
    };
    const onMouse = (e: MouseEvent) => setFrom(e.clientX, e.clientY);
    const onTouch = (e: TouchEvent) => {
      if (e.touches[0]) setFrom(e.touches[0].clientX, e.touches[0].clientY);
    };

    window.addEventListener("mousemove", onMouse, { passive: true });
    window.addEventListener("touchmove", onTouch, { passive: true });
    return () => {
      window.removeEventListener("mousemove", onMouse);
      window.removeEventListener("touchmove", onTouch);
    };
  }, []);

  return pointer;
}
