import Link from "next/link";
import { forwardRef } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "outline" | "ghost";
type Size = "sm" | "md" | "lg";

const base =
  "btn-focus inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-all duration-300 disabled:pointer-events-none disabled:opacity-50";

const variants: Record<Variant, string> = {
  primary:
    "btn-shine bg-gradient-to-r from-primary to-neon-cyan text-void font-bold shadow-[0_0_30px_-6px_rgba(34,211,238,0.6)] hover:shadow-[0_0_44px_-4px_rgba(34,211,238,0.85)] active:scale-[0.98]",
  secondary:
    "bg-white text-void hover:bg-slate-100 active:scale-[0.98]",
  outline:
    "border border-white/20 bg-white/5 text-white backdrop-blur hover:border-neon-cyan/60 hover:bg-white/10 active:scale-[0.98]",
  ghost: "text-slate-300 hover:bg-white/10 hover:text-white",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-4 text-sm",
  md: "h-11 px-6 text-sm",
  lg: "h-[3.25rem] px-8 text-base",
};

interface CommonProps {
  variant?: Variant;
  size?: Size;
  className?: string;
}

interface ButtonAsButton
  extends CommonProps,
    React.ButtonHTMLAttributes<HTMLButtonElement> {
  href?: undefined;
}

interface ButtonAsLink extends CommonProps {
  href: string;
  external?: boolean;
  children?: React.ReactNode;
}

type ButtonProps = ButtonAsButton | ButtonAsLink;

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  function Button(props, ref) {
    const { variant = "primary", size = "md", className } = props;
    const classes = cn(base, variants[variant], sizes[size], className);

    if ("href" in props && props.href !== undefined) {
      const { href, external, children } = props as ButtonAsLink;
      if (external) {
        return (
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className={classes}
          >
            {children}
          </a>
        );
      }
      return (
        <Link href={href} className={classes}>
          {children}
        </Link>
      );
    }

    const { variant: _v, size: _s, className: _c, ...rest } =
      props as ButtonAsButton;
    return <button ref={ref} className={classes} {...rest} />;
  }
);
