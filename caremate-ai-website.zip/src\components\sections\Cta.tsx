"use client";

import { motion } from "framer-motion";
import { StoreButtons } from "@/components/ui/StoreButtons";
import { BackgroundVideo } from "@/components/media/BackgroundVideo";
import { Aurora } from "@/components/media/Aurora";

export function Cta() {
  return (
    <section className="py-20 sm:py-28">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="noise-overlay relative isolate overflow-hidden rounded-[2.5rem] border border-white/10 bg-abyss px-6 py-20 text-center sm:px-12 sm:py-24"
        >
          {/* Cinematic background video (falls back to the animated aurora) */}
          <BackgroundVideo
            video="cta"
            overlayClassName="bg-void/70"
            fallback={<Aurora tone="mixed" />}
          />

          <div className="relative mx-auto max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-white/70 backdrop-blur">
              Start today · It&apos;s free
            </span>
            <h2 className="mt-6 text-4xl font-extrabold leading-[1.05] tracking-tight text-white sm:text-5xl md:text-6xl">
              Start your health
              <br />
              <span className="text-gradient">journey today</span>
            </h2>
            <p className="mt-5 text-lg text-slate-300">
              Download CareMate AI on Google Play — free to start, no card required.
            </p>
            <div className="mt-9 flex justify-center animate-pulse-glow rounded-2xl">
              <StoreButtons />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
