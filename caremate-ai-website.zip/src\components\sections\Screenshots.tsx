"use client";

import { useRef } from "react";
import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { PhoneFrame } from "@/components/phone/PhoneFrame";
import { BackgroundVideo } from "@/components/media/BackgroundVideo";
import { Aurora } from "@/components/media/Aurora";
import {
  ScanScreen,
  DashboardScreen,
  ProgressScreen,
} from "@/components/phone/AppScreens";

const slides = [
  { key: "dashboard", label: "Health Dashboard", Screen: DashboardScreen },
  { key: "scan", label: "AI Food Scanner", Screen: ScanScreen },
  { key: "progress", label: "Progress & Streaks", Screen: ProgressScreen },
  { key: "dashboard2", label: "Daily Overview", Screen: DashboardScreen },
];

export function Screenshots() {
  const trackRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 1 | -1) => {
    const el = trackRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * (el.clientWidth * 0.6), behavior: "smooth" });
  };

  return (
    <section
      id="screenshots"
      className="noise-overlay relative isolate scroll-mt-24 overflow-hidden py-24 sm:py-32"
    >
      <BackgroundVideo
        video="phone"
        overlayClassName="bg-void/80"
        fallback={<Aurora tone="purple" />}
      />
      <div className="container relative z-10">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading
            align="left"
            eyebrow="A closer look"
            title="Designed to feel calm and effortless"
            description="Every screen is built for clarity — the kind of product experience you actually enjoy opening."
          />
          <div className="hidden gap-2 sm:flex">
            <button
              onClick={() => scroll(-1)}
              aria-label="Previous"
              className="btn-focus grid h-11 w-11 place-items-center rounded-full border border-white/15 bg-white/5 text-white backdrop-blur transition-colors hover:border-neon-cyan/60 hover:text-neon-cyan"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={() => scroll(1)}
              aria-label="Next"
              className="btn-focus grid h-11 w-11 place-items-center rounded-full border border-white/15 bg-white/5 text-white backdrop-blur transition-colors hover:border-neon-cyan/60 hover:text-neon-cyan"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      <div
        ref={trackRef}
        className="no-scrollbar mask-fade-x relative z-10 mt-12 flex snap-x snap-mandatory gap-8 overflow-x-auto px-5 pb-6 sm:px-[max(1.25rem,calc((100vw-1200px)/2+1.25rem))]"
      >
        {slides.map((slide, i) => (
          <motion.div
            key={slide.key}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: (i % 4) * 0.08 }}
            className="w-[240px] shrink-0 snap-center sm:w-[260px]"
          >
            <PhoneFrame glow={false}>
              <slide.Screen />
            </PhoneFrame>
            <p className="mt-5 text-center text-sm font-semibold text-slate-300">
              {slide.label}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
