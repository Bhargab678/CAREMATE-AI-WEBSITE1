"use client";

import { useEffect, useRef } from "react";
import { useReducedMotion } from "framer-motion";
import { Smartphone, ScanLine, Sparkles, BarChart3, HeartPulse } from "lucide-react";
import { BackgroundVideo } from "@/components/media/BackgroundVideo";
import { Aurora } from "@/components/media/Aurora";

const STEPS = [
  { n: "01", Icon: Smartphone, title: "Open the app", copy: "One tap from your home screen. No setup, no friction." },
  { n: "02", Icon: ScanLine, title: "Scan your meal", copy: "Point the camera at your plate — or describe it in plain words." },
  { n: "03", Icon: Sparkles, title: "AI analyzes it", copy: "Vision AI identifies every item and matches our verified database." },
  { n: "04", Icon: BarChart3, title: "Get your nutrition", copy: "Calories, macros and micronutrients appear in seconds." },
  { n: "05", Icon: HeartPulse, title: "Improve your health", copy: "Daily insights and streaks turn data into lasting habits." },
];

/**
 * Apple-style pinned horizontal storytelling. The section pins while the track
 * translates horizontally, driven by scroll. Falls back to a normal vertical
 * stack under prefers-reduced-motion (and on very small screens GSAP simply
 * scrubs a shorter distance).
 */
export function StoryScroll() {
  const reduce = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (reduce) return;
    const section = sectionRef.current;
    const track = trackRef.current;
    if (!section || !track) return;

    let ctx: { revert: () => void } | undefined;

    (async () => {
      const [{ default: gsap }, { ScrollTrigger }] = await Promise.all([
        import("gsap"),
        import("gsap/ScrollTrigger"),
      ]);
      gsap.registerPlugin(ScrollTrigger);

      ctx = gsap.context(() => {
        const distance = () => track.scrollWidth - window.innerWidth;

        gsap.to(track, {
          x: () => -distance(),
          ease: "none",
          scrollTrigger: {
            trigger: section,
            start: "top top",
            end: () => `+=${distance()}`,
            pin: true,
            scrub: 1,
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        });

        // Panels rise + fade as they enter.
        gsap.utils.toArray<HTMLElement>(".story-panel").forEach((panel) => {
          gsap.from(panel, {
            opacity: 0,
            y: 60,
            duration: 0.6,
            scrollTrigger: {
              trigger: panel,
              containerAnimation: undefined,
              start: "top 90%",
              once: true,
            },
          });
        });
      }, section);

      ScrollTrigger.refresh();
    })();

    return () => ctx?.revert();
  }, [reduce]);

  return (
    <section
      ref={sectionRef}
      id="how-it-works"
      className="noise-overlay relative isolate overflow-hidden scroll-mt-24"
    >
      <BackgroundVideo
        video="story"
        overlayClassName="bg-void/75"
        fallback={<Aurora tone="purple" />}
      />

      <div className="relative z-10 flex min-h-screen flex-col justify-center py-20">
        <div className="container">
          <span className="eyebrow">The journey</span>
          <h2 className="h-section mt-5 max-w-2xl">
            From plate to progress, in five moments
          </h2>
        </div>

        {/* Horizontal track (vertical stack when reduced motion) */}
        <div
          ref={trackRef}
          className={
            reduce
              ? "container mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
              : "mt-14 flex w-max gap-6 px-5 sm:px-8 lg:px-16"
          }
        >
          {STEPS.map((s) => (
            <article
              key={s.n}
              className={`story-panel card-dark group relative flex flex-col justify-between p-8 ${
                reduce ? "" : "h-[380px] w-[300px] shrink-0 sm:w-[360px]"
              }`}
            >
              <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-neon-cyan/60 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
              <div>
                <span className="font-display text-5xl font-extrabold text-white/10">
                  {s.n}
                </span>
                <div className="mt-4 grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-primary/25 to-neon-cyan/15 text-neon-cyan ring-1 ring-white/10">
                  <s.Icon className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{s.copy}</p>
              </div>
            </article>
          ))}
        </div>

        {!reduce && (
          <p className="container mt-10 text-xs font-medium uppercase tracking-[0.2em] text-slate-500">
            Keep scrolling →
          </p>
        )}
      </div>
    </section>
  );
}
