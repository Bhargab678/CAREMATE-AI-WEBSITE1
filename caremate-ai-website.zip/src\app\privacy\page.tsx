import type { Metadata } from "next";
import { LegalPage } from "@/components/layout/LegalPage";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "How CareMate AI collects, uses and protects your personal and health data.",
  alternates: { canonical: "/privacy" },
  robots: { index: true, follow: true },
};

export default function PrivacyPage() {
  return (
    <LegalPage
      title="Privacy Policy"
      updated="July 21, 2026"
      intro={`Your privacy matters to us. This Privacy Policy explains how ${siteConfig.name} ("we", "us") collects, uses, and safeguards your information when you use our mobile application and website.`}
      sections={[
        {
          heading: "Information we collect",
          body: [
            "Account information such as your name and email address when you create an account.",
            "Health and nutrition data you provide, including food photos, meals, calories, water intake, weight and activity.",
            "Usage data such as device type, app version and anonymised interaction analytics used to improve the product.",
          ],
        },
        {
          heading: "How we use your information",
          body: [
            "To provide core features, including food recognition, nutrition analysis and your personal health dashboard.",
            "To personalise AI insights and recommendations based on your goals and patterns.",
            "To maintain security, prevent abuse, and comply with legal obligations.",
          ],
        },
        {
          heading: "Photo and image processing",
          body: [
            "Food photos are processed to identify items and match them to our verified nutrition database. Where technically possible, recognition happens on-device.",
            "We do not use your photos to train third-party models without your explicit consent.",
          ],
        },
        {
          heading: "Data sharing",
          body: [
            "We do not sell your personal data. We may share limited data with trusted service providers strictly to operate the app (for example, cloud hosting), under contractual confidentiality obligations.",
          ],
        },
        {
          heading: "Data retention and your rights",
          body: [
            "You can export or delete your data at any time from within the app.",
            "Depending on your region, you may have rights to access, correct, or erase your personal data, and to object to certain processing.",
          ],
        },
        {
          heading: "Security",
          body: [
            "We use industry-standard encryption in transit and at rest, and follow the principle of least privilege for internal access.",
          ],
        },
        {
          heading: "Children's privacy",
          body: [
            "CareMate AI is not directed to children under 13, and we do not knowingly collect personal data from them.",
          ],
        },
        {
          heading: "Contact us",
          body: [
            `If you have questions about this policy, email us at ${siteConfig.email}.`,
          ],
        },
      ]}
    />
  );
}
