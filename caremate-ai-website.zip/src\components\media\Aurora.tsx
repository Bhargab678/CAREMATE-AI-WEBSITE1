"use client";

import { cn } from "@/lib/utils";

type Tone = "cyan" | "purple" | "mixed" | "emerald";

const TONES: Record<Tone, string[]> = {
  cyan: ["rgba(34,211,238,0.30)", "rgba(59,130,246,0.24)", "rgba(16,185,129,0.18)"],
  purple: ["rgba(168,85,247,0.30)", "rgba(59,130,246,0.22)", "rgba(34,211,238,0.16)"],
  emerald: ["rgba(16,185,129,0.30)", "rgba(34,197,94,0.20)", "rgba(34,211,238,0.16)"],
  mixed: ["rgba(168,85,247,0.26)", "rgba(34,211,238,0.26)", "rgba(16,185,129,0.20)"],
};

/**
 * Animated aurora wash — the premium fallback used behind every section until
 * real video assets are supplied. Pure CSS transforms, GPU-friendly.
 */
export function Aurora({
  tone = "mixed",
  className,
  grid = true,
}: {
  tone?: Tone;
  className?: string;
  grid?: boolean;
}) {
  const [a, b, c] = TONES[tone];
  return (
    <div aria-hidden className={cn("aurora-layer", className)}>
      <div
        className="aurora-blob"
        style={{ background: a, width: 620, height: 620, top: "-18%", left: "-10%" }}
      />
      <div
        className="aurora-blob"
        style={{
          background: b,
          width: 520,
          height: 520,
          bottom: "-20%",
          right: "-8%",
          animationDelay: "-6s",
        }}
      />
      <div
        className="aurora-blob"
        style={{
          background: c,
          width: 420,
          height: 420,
          top: "30%",
          left: "45%",
          animationDelay: "-11s",
        }}
      />
      {grid && (
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:52px_52px] [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" />
      )}
    </div>
  );
}
