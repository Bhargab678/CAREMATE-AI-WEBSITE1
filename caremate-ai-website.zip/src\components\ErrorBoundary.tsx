"use client";

import { Component, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  /** Rendered instead of the children when they throw. Defaults to nothing. */
  fallback?: ReactNode;
  /** Optional label to make dev-console logs easy to trace. */
  label?: string;
}

interface State {
  hasError: boolean;
}

/**
 * Client error boundary. Isolates a subtree (e.g. the WebGL hero) so that if it
 * throws — unsupported GPU, lost context, a bad frame — it degrades to the
 * fallback instead of white-screening the entire page.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    if (process.env.NODE_ENV !== "production") {
      // eslint-disable-next-line no-console
      console.warn(
        `[ErrorBoundary${this.props.label ? `: ${this.props.label}` : ""}] caught`,
        error
      );
    }
  }

  render() {
    if (this.state.hasError) return this.props.fallback ?? null;
    return this.props.children;
  }
}
