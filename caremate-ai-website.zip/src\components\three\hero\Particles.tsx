"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { seeded } from "./utils";
import { PALETTE } from "./config";

/**
 * Thousands of tiny glowing particles rendered as a single THREE.Points draw
 * call. A small custom shader gives each particle an independent twinkle (fade
 * in/out) and a soft round shape — GPU-cheap and leak-free.
 */
export function Particles({ count, reduced }: { count: number; reduced: boolean }) {
  const matRef = useRef<THREE.ShaderMaterial>(null);
  const pointsRef = useRef<THREE.Points>(null);

  const { positions, phases, sizes, colors } = useMemo(() => {
    const rand = seeded(1337);
    const positions = new Float32Array(count * 3);
    const phases = new Float32Array(count);
    const sizes = new Float32Array(count);
    const colors = new Float32Array(count * 3);

    const palette = [
      new THREE.Color(PALETTE.primary),
      new THREE.Color(PALETTE.sky),
      new THREE.Color("#ffffff"),
      new THREE.Color(PALETTE.blue),
    ];

    for (let i = 0; i < count; i++) {
      const r = 5 + rand() * 12;
      const theta = rand() * Math.PI * 2;
      const phi = Math.acos(rand() * 2 - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = (rand() * 2 - 1) * 7;
      positions[i * 3 + 2] = r * Math.cos(phi) * 0.6 - 3;
      phases[i] = rand() * Math.PI * 2;
      sizes[i] = 1 + rand() * 2.5;
      const c = palette[Math.floor(rand() * palette.length)];
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    return { positions, phases, sizes, colors };
  }, [count]);

  const uniforms = useMemo(
    () => ({ uTime: { value: 0 }, uSize: { value: 26 } }),
    []
  );

  useFrame((state) => {
    if (matRef.current) {
      matRef.current.uniforms.uTime.value = reduced
        ? 0
        : state.clock.elapsedTime;
    }
    if (pointsRef.current && !reduced) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} count={count} />
        <bufferAttribute attach="attributes-aPhase" args={[phases, 1]} count={count} />
        <bufferAttribute attach="attributes-aSize" args={[sizes, 1]} count={count} />
        <bufferAttribute attach="attributes-aColor" args={[colors, 3]} count={count} />
      </bufferGeometry>
      <shaderMaterial
        ref={matRef}
        uniforms={uniforms}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        vertexShader={`
          uniform float uTime;
          uniform float uSize;
          attribute float aPhase;
          attribute float aSize;
          attribute vec3 aColor;
          varying float vTwinkle;
          varying vec3 vColor;
          void main() {
            vColor = aColor;
            vTwinkle = 0.35 + 0.65 * (0.5 + 0.5 * sin(uTime * 1.6 + aPhase));
            vec4 mv = modelViewMatrix * vec4(position, 1.0);
            gl_PointSize = uSize * aSize / -mv.z;
            gl_Position = projectionMatrix * mv;
          }
        `}
        fragmentShader={`
          varying float vTwinkle;
          varying vec3 vColor;
          void main() {
            float d = distance(gl_PointCoord, vec2(0.5));
            if (d > 0.5) discard;
            float alpha = smoothstep(0.5, 0.0, d) * vTwinkle;
            gl_FragColor = vec4(vColor, alpha);
          }
        `}
      />
    </points>
  );
}
