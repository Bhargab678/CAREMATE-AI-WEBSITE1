"use client";

import type { ReactNode } from "react";
import { BackgroundVideo } from "@/components/media/BackgroundVideo";
import { Aurora } from "@/components/media/Aurora";
import type { VideoKey } from "@/lib/media";
import { cn } from "@/lib/utils";

/**
 * A full-bleed section with a cinematic backdrop: a looping background video
 * when assets are available, an animated aurora fallback otherwise. Content is
 * rendered above a readability scrim.
 */
export function CinematicSection({
  id,
  video,
  tone = "mixed",
  overlay = "bg-void/70",
  className,
  innerClassName,
  full = false,
  grid = true,
  children,
}: {
  id?: string;
  video?: VideoKey;
  tone?: "cyan" | "purple" | "mixed" | "emerald";
  overlay?: string;
  className?: string;
  innerClassName?: string;
  /** stretch to 100vh */
  full?: boolean;
  grid?: boolean;
  children: ReactNode;
}) {
  return (
    <section
      id={id}
      className={cn(
        "noise-overlay relative isolate overflow-hidden scroll-mt-24",
        full ? "flex min-h-screen items-center py-24" : "py-24 sm:py-32",
        className
      )}
    >
      <BackgroundVideo
        video={video}
        overlayClassName={overlay}
        fallback={<Aurora tone={tone} grid={grid} />}
      />
      <div className={cn("container relative z-10", innerClassName)}>{children}</div>
    </section>
  );
}
