import * as THREE from "three";

/** Deterministic pseudo-random from a seed — stable across renders. */
export function seeded(seed: number): () => number {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/** Frame-rate independent damping toward a target. */
export function damp(current: number, target: number, lambda: number, dt: number): number {
  return THREE.MathUtils.damp(current, target, lambda, dt);
}

/** Pick a quality tier from device signals (runs client-side only). */
export function detectQuality(): "high" | "mid" | "low" {
  if (typeof window === "undefined") return "mid";
  const cores = navigator.hardwareConcurrency ?? 4;
  const mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 4;
  const mobile = window.matchMedia("(max-width: 767px)").matches;
  const coarse = window.matchMedia("(pointer: coarse)").matches;

  if (mobile || coarse || cores <= 4 || mem <= 3) return "low";
  if (cores <= 8 || mem <= 6) return "mid";
  return "high";
}
