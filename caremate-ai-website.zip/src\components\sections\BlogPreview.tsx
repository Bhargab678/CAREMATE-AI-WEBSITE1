import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/motion/Reveal";
import { BlogCard } from "@/components/blog/BlogCard";
import type { BlogPostMeta } from "@/lib/blog";

export function BlogPreview({ posts }: { posts: BlogPostMeta[] }) {
  if (!posts.length) return null;
  return (
    <section className="relative py-24 sm:py-32">
      <div className="container">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading
            align="left"
            eyebrow="From the blog"
            title="Insights for a healthier life"
            description="Evidence-based articles on nutrition, habits and mindful eating."
          />
          <Reveal>
            <Link
              href="/blog"
              className="btn-focus inline-flex items-center gap-1.5 rounded-full text-sm font-semibold text-neon-cyan hover:gap-2.5 transition-all"
            >
              View all articles <ArrowRight className="h-4 w-4" />
            </Link>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {posts.slice(0, 3).map((post, i) => (
            <Reveal key={post.slug} delay={i * 0.08}>
              <BlogCard post={post} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
