import { PageHeader } from "@/components/layout/PageHeader";

export interface LegalSection {
  heading: string;
  body: string[];
}

export function LegalPage({
  title,
  updated,
  intro,
  sections,
}: {
  title: string;
  updated: string;
  intro: string;
  sections: LegalSection[];
}) {
  return (
    <>
      <PageHeader eyebrow="Legal" title={title} />
      <section className="pb-24">
        <div className="container-tight">
          <p className="text-sm text-slate-500">Last updated: {updated}</p>
          <div className="prose-caremate mt-8 max-w-none">
            <p className="lead text-lg text-slate-300">{intro}</p>
            {sections.map((section, i) => (
              <div key={section.heading}>
                <h2>
                  {i + 1}. {section.heading}
                </h2>
                {section.body.map((p, j) => (
                  <p key={j}>{p}</p>
                ))}
              </div>
            ))}
            <hr />
            <p className="text-sm text-slate-500">
              This document is a template provided for convenience and does not
              constitute legal advice. Please consult a qualified professional
              before publishing your production policies.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
