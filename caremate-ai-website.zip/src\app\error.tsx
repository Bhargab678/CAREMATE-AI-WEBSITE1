"use client";

import { useEffect } from "react";
import Link from "next/link";

/**
 * Route-segment error boundary. Catches render/runtime errors in any page so the
 * shell (nav, footer) survives and the user gets a retry instead of a blank page.
 */
export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // eslint-disable-next-line no-console
    console.error("Route error:", error);
  }, [error]);

  return (
    <section className="flex min-h-[70vh] items-center justify-center px-6 py-32 text-center">
      <div className="max-w-md">
        <p className="text-sm font-semibold uppercase tracking-widest text-neon-cyan">
          Something went wrong
        </p>
        <h1 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
          This page hit a snag
        </h1>
        <p className="mt-4 text-slate-400">
          An unexpected error occurred while loading this section. You can try
          again, or head back to the home page.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <button
            onClick={reset}
            className="btn-focus inline-flex h-12 items-center justify-center rounded-full bg-primary px-7 text-sm font-semibold text-white transition-colors hover:bg-primary-600"
          >
            Try again
          </button>
          <Link
            href="/"
            className="btn-focus inline-flex h-12 items-center justify-center rounded-full border border-white/20 bg-white/5 px-7 text-sm font-semibold text-white transition-colors hover:bg-white/10"
          >
            Back to home
          </Link>
        </div>
      </div>
    </section>
  );
}
