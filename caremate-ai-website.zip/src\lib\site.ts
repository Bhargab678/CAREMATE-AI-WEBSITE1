export const siteConfig = {
  name: "CareMate AI",
  shortName: "CareMate",
  tagline: "AI Food Scanner & Personal Health Assistant",
  description:
    "Scan meals instantly using AI. Analyze calories, nutrition, meal plans, AI chat, health reports and more with CareMate AI.",
  // Overridable for deployment; falls back to the production domain so builds
  // never crash when the env var is absent.
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://caremate-ai.com",
  ogImage: "/og.png",
  locale: "en_US",
  keywords: [
    "AI food scanner",
    "calorie tracker",
    "nutrition tracking app",
    "AI nutrition analysis",
    "health dashboard",
    "food recognition",
    "macro tracking",
    "healthy lifestyle app",
    "CareMate AI",
  ],
  author: "CareMate AI",
  email: "hello@caremate-ai.com",
  // Set to true once the iOS app is published to show the App Store button.
  appStoreLive: false,
  links: {
    playStore:
      "https://play.google.com/store/apps/details?id=com.bhargab.healthai.app",
    // App Store link not available yet — set this and flip `appStoreLive` to true to show it.
    appStore: "https://apps.apple.com/app",
    twitter: "https://twitter.com/caremateai",
    instagram: "https://instagram.com/caremateai",
    linkedin: "https://linkedin.com/company/caremateai",
    github: "https://github.com/caremateai",
  },
} as const;

export type SiteConfig = typeof siteConfig;

export const navLinks = [
  { label: "Features", href: "/#features" },
  { label: "How it works", href: "/#how-it-works" },
  { label: "About", href: "/about" },
  { label: "Blog", href: "/blog" },
  { label: "Contact", href: "/contact" },
] as const;
