"use client";

import dynamic from "next/dynamic";
import { motion, useReducedMotion } from "framer-motion";
import { Star, ShieldCheck, PlayCircle } from "lucide-react";
import { PhoneFrame } from "@/components/phone/PhoneFrame";
import { DashboardScreen } from "@/components/phone/AppScreens";
import { StoreButtons } from "@/components/ui/StoreButtons";
import { Counter } from "@/components/motion/Counter";
import { BackgroundVideo } from "@/components/media/BackgroundVideo";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { stats } from "@/lib/content";

// Fullscreen R3F hero background — client-only, streamed in after paint.
const HeroCanvas = dynamic(() => import("@/components/three/hero/HeroCanvas"), {
  ssr: false,
});

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1, delayChildren: 0.1 } },
};
const item = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
};

export function Hero() {
  const reduce = useReducedMotion();

  return (
    <section className="noise-overlay relative isolate flex min-h-screen flex-col justify-center overflow-hidden bg-void pt-28 pb-16 sm:pt-32 lg:pt-36 lg:pb-20">
      {/* 3D backdrop + readability overlays */}
      <div aria-hidden className="absolute inset-0 -z-10">
        <div className="absolute inset-0">
          <ErrorBoundary label="HeroCanvas">
            <HeroCanvas />
          </ErrorBoundary>
        </div>
        {/* optional cinematic hero video (enable in src/lib/media.ts) */}
        <BackgroundVideo video="hero" eager overlayClassName="bg-void/55" />
        {/* left-side scrim keeps headline crisp over the scene */}
        <div className="absolute inset-0 bg-gradient-to-r from-void via-void/70 to-void/10 lg:to-transparent" />
        {/* gentle vignette + bottom depth */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,transparent_40%,rgba(5,5,5,0.7))]" />
      </div>

      <div className="container grid items-center gap-14 lg:grid-cols-2">
        <motion.div variants={container} initial="hidden" animate="show">
          <motion.div variants={item}>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-white/70 backdrop-blur">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" />
              Verified nutrition · never estimated
            </span>
          </motion.div>

          <motion.h1
            variants={item}
            className="mt-6 text-4xl font-extrabold leading-[1.03] tracking-tight text-white sm:text-5xl lg:text-[4rem]"
          >
            Your personal
            <br />
            <span className="text-gradient">AI health assistant</span>
          </motion.h1>

          <motion.p
            variants={item}
            className="mt-6 max-w-xl text-lg leading-relaxed text-slate-300"
          >
            Scan food. Track nutrition. Chat with AI.
            <br className="hidden sm:block" />
            Build healthier habits — effortlessly.
          </motion.p>

          <motion.div variants={item} className="mt-8 flex flex-wrap items-center gap-4">
            <StoreButtons />
            <a
              href="#scanner"
              className="btn-focus inline-flex h-14 items-center gap-2.5 rounded-2xl border border-white/20 bg-white/5 px-6 text-sm font-semibold text-white backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:border-neon-cyan/60 hover:bg-white/10"
            >
              <PlayCircle className="h-5 w-5 text-neon-cyan" />
              Watch demo
            </a>
          </motion.div>

          <motion.div
            variants={item}
            className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-slate-400"
          >
            <span className="inline-flex items-center gap-1.5">
              <span className="flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                ))}
              </span>
              4.9 average rating
            </span>
            <span className="hidden h-4 w-px bg-white/15 sm:block" />
            <span>Loved by 1M+ health-conscious users</span>
          </motion.div>
        </motion.div>

        {/* phone */}
        <motion.div
          initial={{ opacity: 0, y: 40, rotate: -2 }}
          animate={{ opacity: 1, y: 0, rotate: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
          className="relative mx-auto"
        >
          <motion.div
            animate={reduce ? undefined : { y: [0, -14, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          >
            <PhoneFrame>
              <DashboardScreen />
            </PhoneFrame>
          </motion.div>

          {/* floating chips */}
          <FloatingChip
            className="-left-6 top-16"
            delay={0.6}
            emoji="🔥"
            title="360 kcal"
            sub="logged today"
          />
          <FloatingChip
            className="-right-4 bottom-28"
            delay={0.9}
            emoji="🥭"
            title="Mango"
            sub="98% match"
          />
        </motion.div>
      </div>

      {/* stat strip */}
      <div className="container mt-16 lg:mt-24">
        <div className="grid grid-cols-2 gap-4 rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur sm:grid-cols-4 sm:p-8">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.5 }}
              className="text-center"
            >
              <Counter
                value={s.value}
                className="block text-2xl font-extrabold text-white sm:text-3xl"
              />
              <p className="mt-1 text-xs font-medium uppercase tracking-wide text-slate-400">
                {s.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* scroll indicator */}
      <motion.a
        href="#features"
        aria-label="Scroll to features"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 0.6 }}
        className="btn-focus mx-auto mt-12 hidden w-fit flex-col items-center gap-2 text-white/50 transition-colors hover:text-white lg:flex"
      >
        <span className="text-[11px] font-medium uppercase tracking-widest">Scroll</span>
        <span className="flex h-9 w-5 items-start justify-center rounded-full border-2 border-current p-1">
          <span className="scroll-dot h-1.5 w-1.5 rounded-full bg-current" />
        </span>
      </motion.a>
    </section>
  );
}

function FloatingChip({
  className,
  emoji,
  title,
  sub,
  delay = 0,
}: {
  className?: string;
  emoji: string;
  title: string;
  sub: string;
  delay?: number;
}) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, duration: 0.5 }}
      className={`absolute z-20 hidden sm:block ${className ?? ""}`}
    >
      <motion.div
        animate={reduce ? undefined : { y: [0, -10, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay }}
        className="flex items-center gap-2.5 rounded-2xl border border-white/60 bg-white/85 px-3.5 py-2.5 shadow-card backdrop-blur-xl"
      >
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-primary/10 text-base">
          {emoji}
        </span>
        <span className="flex flex-col leading-tight">
          <span className="text-sm font-bold text-ink">{title}</span>
          <span className="text-[11px] text-muted">{sub}</span>
        </span>
      </motion.div>
    </motion.div>
  );
}
