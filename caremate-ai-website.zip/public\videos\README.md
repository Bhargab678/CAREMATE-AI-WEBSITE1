# Cinematic background videos

Drop your optimized videos here, then set `videoBackgrounds: true` in
[`src/lib/media.ts`](../../src/lib/media.ts). Every section upgrades
automatically — lazy-loading, off-screen pausing, poster frames and
`prefers-reduced-motion` fallbacks are already wired up.

Until you add these files (and flip the flag), each section renders its animated
**aurora** fallback, so the site always looks finished and there are no broken
video requests.

## Required files

Each row needs three files: `<name>.webm`, `<name>.mp4`, `<name>-poster.jpg`.

| Name | Section | Overlay | Suggested theme |
| --- | --- | --- | --- |
| `hero` | S1 — fullscreen hero | 55% void | Neural network, DNA, medical holograms, blue particle field |
| `phone` | S2 — app showcase | 80% void | 3D phone rotating, app UI playing inside |
| `scanner` | S3 — food scanner | 76% void | Meal on table, camera scan, AI particles, nutrition appears |
| `story` | S4 — horizontal story | 75% void | Abstract flowing gradient / data streams |
| `features` | S5 — feature grid | 82% void | Soft tech ambience, slow particles |
| `chat` | S6 — AI chat | 78% void | Animated AI hologram / voice waveform |
| `stats` | S7 — stats band | 80% void | Moving digital particles, counters |
| `testimonials` | S8 — testimonials | 82% void | Slow-motion gradient waves |
| `pricing` | Pricing | 80% void | Soft glowing particles, abstract AI |
| `cta` | S9 — download CTA | 70% void | Epic cinematic healthcare technology |
| `footer` | Footer | — | Animated wave / digital grid |

> Only `hero` is preloaded eagerly. Everything else lazy-loads and pauses when
> scrolled out of view, so it costs nothing until the user reaches it.

## Recommended specs

- **Formats:** WebM (VP9) primary + MP4 (H.264) fallback — both `<source>` tags
  are emitted automatically.
- **Length:** 10–20 s, seamlessly looping.
- **No audio track** (autoplay requires muted).
- **Size budget:** hero < 8 MB, all others < 2 MB each.
- **Resolution:** master at 4K if you like, but export ~1080p for delivery — it's
  a background behind a dark scrim, so heavy compression is invisible and keeps
  Lighthouse green.
- **Poster:** ~1600px wide JPG, optimized (< 200 KB).

## Compression commands (ffmpeg)

```bash
ffmpeg -i source.mov -t 18 -vf "scale=1920:-2" -c:v libx264 -crf 28 -preset slow -an -movflags +faststart hero.mp4
```

```bash
ffmpeg -i source.mov -t 18 -vf "scale=1920:-2" -c:v libvpx-vp9 -crf 34 -b:v 0 -an hero.webm
```

```bash
ffmpeg -i hero.mp4 -ss 00:00:02 -vframes 1 -q:v 3 hero-poster.jpg
```
