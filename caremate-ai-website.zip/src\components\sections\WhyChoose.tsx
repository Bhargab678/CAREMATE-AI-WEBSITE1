"use client";

import { motion } from "framer-motion";
import { Check, X } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { staggerContainer, staggerItem } from "@/components/motion/Reveal";
import { Aurora } from "@/components/media/Aurora";
import { advantages, comparison } from "@/lib/content";

export function WhyChoose() {
  return (
    <section className="noise-overlay relative isolate overflow-hidden py-24 sm:py-32">
      <Aurora tone="emerald" />
      <div className="container relative z-10">
        <SectionHeading
          eyebrow="Why CareMate AI"
          title="The trustworthy way to track nutrition"
          description="Built for accuracy and calm — not another cluttered calorie counter."
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4"
        >
          {advantages.map((adv) => (
            <motion.div
              key={adv.title}
              variants={staggerItem}
              className="card-dark card-hover glow-ring p-6"
            >
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-primary/25 to-neon-cyan/10 text-neon-cyan ring-1 ring-white/10">
                <adv.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-base font-bold text-white">{adv.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">
                {adv.description}
              </p>
            </motion.div>
          ))}
        </motion.div>

        {/* comparison table */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="card-dark mx-auto mt-12 max-w-3xl overflow-hidden"
        >
          <div className="grid grid-cols-[1.3fr_1fr_1fr] items-center border-b border-white/10 bg-white/[0.04] px-5 py-4 text-sm font-semibold sm:px-8">
            <span className="text-slate-500">Compare</span>
            <span className="flex items-center justify-center gap-1.5 text-neon-cyan">
              CareMate AI
            </span>
            <span className="text-center text-slate-500">Other apps</span>
          </div>
          {comparison.map((row, i) => (
            <div
              key={row.label}
              className={`grid grid-cols-[1.3fr_1fr_1fr] items-center px-5 py-4 text-sm sm:px-8 ${
                i % 2 ? "bg-white/[0.02]" : "bg-transparent"
              }`}
            >
              <span className="font-medium text-slate-200">{row.label}</span>
              <span className="flex items-center justify-center gap-1.5 text-center font-semibold text-white">
                <Check className="h-4 w-4 shrink-0 text-primary" />
                <span className="hidden sm:inline">{row.caremate}</span>
              </span>
              <span className="flex items-center justify-center gap-1.5 text-center text-slate-500">
                <X className="h-4 w-4 shrink-0 text-slate-600" />
                <span className="hidden sm:inline">{row.others}</span>
              </span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
