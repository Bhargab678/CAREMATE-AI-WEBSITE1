"use client";

import { useState } from "react";
import { motion, LayoutGroup } from "framer-motion";
import { Check, Sparkles } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { BackgroundVideo } from "@/components/media/BackgroundVideo";
import { plans } from "@/lib/content";
import { siteConfig } from "@/lib/site";
import { cn } from "@/lib/utils";

export function Pricing() {
  const [annual, setAnnual] = useState(true);

  return (
    <section id="pricing" className="relative scroll-mt-24 overflow-hidden py-20 sm:py-28">
      <BackgroundVideo
        video="pricing"
        overlayClassName="bg-void/80"
        fallback={
          <>
            <div className="absolute left-[10%] top-[20%] h-72 w-72 animate-blob rounded-full bg-primary/10 blur-3xl" />
            <div className="absolute right-[8%] bottom-[10%] h-72 w-72 animate-blob blob-delay-2 rounded-full bg-secondary/10 blur-3xl" />
          </>
        }
      />
      <div className="container relative">
        <SectionHeading
          eyebrow="Pricing"
          title="Simple plans that grow with you"
          description="Start free forever. Upgrade any time for deeper insight — cancel whenever you like."
        />

        {/* billing toggle */}
        <div className="mt-8 flex items-center justify-center gap-3">
          <span
            className={cn(
              "text-sm font-medium transition-colors",
              !annual ? "text-white" : "text-slate-500"
            )}
          >
            Monthly
          </span>
          <button
            onClick={() => setAnnual((v) => !v)}
            role="switch"
            aria-checked={annual}
            aria-label="Toggle annual billing"
            className={cn(
              "btn-focus relative h-8 w-14 rounded-full p-1 transition-colors duration-300",
              annual ? "bg-gradient-to-r from-primary to-neon-cyan" : "bg-white/15"
            )}
          >
            <motion.span
              layout
              transition={{ type: "spring", stiffness: 500, damping: 32 }}
              className={cn(
                "block h-6 w-6 rounded-full bg-white shadow",
                annual ? "ml-auto" : "ml-0"
              )}
            />
          </button>
          <span
            className={cn(
              "text-sm font-medium transition-colors",
              annual ? "text-white" : "text-slate-500"
            )}
          >
            Annual
          </span>
          <span className="rounded-full bg-neon-cyan/15 px-2.5 py-1 text-xs font-semibold text-neon-cyan ring-1 ring-neon-cyan/30">
            Save 30%
          </span>
        </div>

        <LayoutGroup>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {plans.map((plan, i) => {
              const price = annual ? plan.annual : plan.monthly;
              return (
                <motion.div
                  key={plan.name}
                  initial={{ opacity: 0, y: 28 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.55, delay: i * 0.1 }}
                  className={cn(
                    "relative flex flex-col rounded-3xl border p-7 transition-all duration-300",
                    plan.featured
                      ? "border-neon-cyan/40 bg-white/[0.07] text-white shadow-[0_0_60px_-15px_rgba(34,211,238,0.6)] backdrop-blur-xl lg:-translate-y-3"
                      : "glow-ring border-white/10 bg-white/[0.03] backdrop-blur-xl hover:-translate-y-1 hover:border-white/20"
                  )}
                >
                  {plan.featured && (
                    <span className="absolute right-6 top-6 inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-primary to-neon-cyan px-3 py-1 text-xs font-semibold text-void">
                      <Sparkles className="h-3 w-3" /> Popular
                    </span>
                  )}
                  <h3
                    className={cn(
                      "text-lg font-bold",
                      plan.featured ? "text-white" : "text-white"
                    )}
                  >
                    {plan.name}
                  </h3>
                  <p
                    className={cn(
                      "mt-1.5 min-h-[40px] text-sm leading-relaxed",
                      plan.featured ? "text-white/70" : "text-slate-400"
                    )}
                  >
                    {plan.tagline}
                  </p>

                  <div className="mt-5 flex items-end gap-1">
                    <span
                      className={cn(
                        "text-4xl font-extrabold tabular",
                        plan.featured ? "text-white" : "text-white"
                      )}
                    >
                      ${price}
                    </span>
                    <span
                      className={cn(
                        "mb-1 text-sm",
                        plan.featured ? "text-white/60" : "text-slate-500"
                      )}
                    >
                      {price === 0 ? "forever" : "/ month"}
                    </span>
                  </div>
                  {price > 0 && annual && (
                    <p
                      className={cn(
                        "mt-1 text-xs",
                        plan.featured ? "text-white/50" : "text-slate-500"
                      )}
                    >
                      billed annually
                    </p>
                  )}

                  <ul className="mt-6 flex-1 space-y-3">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-sm">
                        <span
                          className={cn(
                            "mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full",
                            plan.featured ? "bg-neon-cyan text-void" : "bg-neon-cyan/15 text-neon-cyan"
                          )}
                        >
                          <Check className="h-3 w-3" strokeWidth={3} />
                        </span>
                        <span className={plan.featured ? "text-white/85" : "text-slate-300"}>
                          {f}
                        </span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    href={siteConfig.links.playStore}
                    external
                    variant={plan.featured ? "primary" : "outline"}
                    className={cn("btn-shine mt-7 w-full", plan.featured && "shadow-none")}
                  >
                    {plan.cta}
                  </Button>
                </motion.div>
              );
            })}
          </div>
        </LayoutGroup>

        <p className="mt-8 text-center text-sm text-slate-500">
          Prices shown are placeholders — update them in{" "}
          <code className="rounded bg-white/10 px-1.5 py-0.5 text-neon-cyan">
            src/lib/content.ts
          </code>
          .
        </p>
      </div>
    </section>
  );
}
