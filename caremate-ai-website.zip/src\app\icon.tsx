import { ImageResponse } from "next/og";
import { logoTileDataUri } from "@/lib/brand";

export const size = { width: 512, height: 512 };
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={logoTileDataUri} width={512} height={512} alt="" />
      </div>
    ),
    { ...size }
  );
}
